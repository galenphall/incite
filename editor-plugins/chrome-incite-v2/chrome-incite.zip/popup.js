"use strict";
(() => {
  // ../shared/src/types.ts
  var DEFAULT_SETTINGS = {
    apiMode: "cloud",
    cloudUrl: "https://inciteref.com",
    localUrl: "http://127.0.0.1:8230",
    apiToken: "",
    k: 10,
    authorBoost: 1,
    contextSentences: 6,
    citationPatterns: [
      "\\[@[^\\]]*\\]",
      "\\[cite\\]",
      "\\\\cite\\{[^}]*\\}"
    ],
    insertFormat: "({first_author}, {year})",
    autoDetectEnabled: false,
    debounceMs: 500,
    showParagraphs: true
  };

  // src/shared/constants.ts
  var DEFAULT_SETTINGS2 = {
    ...DEFAULT_SETTINGS,
    citationStyle: "apa",
    googleDocsCitationFormat: "({first_author}, {year})",
    overleafCitationFormat: "\\cite{{{bibtex_key}}}",
    showAbstracts: false
  };
  var STORAGE_KEY = "incite_settings";

  // src/shared/settings.ts
  async function loadSettings() {
    const result = await chrome.storage.sync.get(STORAGE_KEY);
    const stored = result[STORAGE_KEY] ?? {};
    const merged = { ...DEFAULT_SETTINGS2, ...stored };
    if (!stored.citationStyle && stored.googleDocsCitationFormat) {
      merged.citationStyle = DEFAULT_SETTINGS2.citationStyle;
      merged.googleDocsCitationFormat = DEFAULT_SETTINGS2.googleDocsCitationFormat;
    }
    return merged;
  }

  // src/popup/popup.ts
  var state = { kind: "loading" };
  var collections = [];
  var selectedCollectionId = null;
  var selectedTags = [];
  var tagSuggestions = [];
  var showTagInput = false;
  var selectedPaperIndices = /* @__PURE__ */ new Set();
  var settings;
  var root = document.getElementById("popup-root");
  (async function init() {
    settings = await loadSettings();
    render();
    if (!settings.apiToken) {
      state = { kind: "not-signed-in" };
      render();
      return;
    }
    try {
      const response = await chrome.runtime.sendMessage({ type: "GET_DETECTED_PAPERS" });
      if (!response || !response.papers || response.papers.length === 0) {
        state = { kind: "no-paper" };
        render();
        return;
      }
      const [collectionsResp, checkResp] = await Promise.all([
        chrome.runtime.sendMessage({ type: "GET_COLLECTIONS" }),
        chrome.runtime.sendMessage({ type: "CHECK_LIBRARY", papers: response.papers })
      ]);
      if (collectionsResp?.collections) {
        collections = collectionsResp.collections;
      }
      const stored = await chrome.storage.local.get("lastCollectionId");
      if (stored.lastCollectionId) {
        selectedCollectionId = stored.lastCollectionId;
      }
      const papers = response.papers;
      const checks = checkResp?.results ?? [];
      if (response.type === "single" && papers.length === 1) {
        const check = checks[0] ?? null;
        if (check?.in_library) {
          state = { kind: "already-saved", paper: papers[0], check };
          if (check.tags?.length) {
            selectedTags = [...check.tags];
            showTagInput = true;
          }
        } else {
          state = { kind: "single-paper", paper: papers[0], check };
        }
      } else {
        papers.forEach((_, i) => {
          if (!checks[i]?.in_library) {
            selectedPaperIndices.add(i);
          }
        });
        state = { kind: "multi-paper", papers, checks };
      }
    } catch (err) {
      state = { kind: "error", message: err instanceof Error ? err.message : "Failed to load" };
    }
    render();
  })();
  function render() {
    switch (state.kind) {
      case "loading":
        root.innerHTML = renderLoading();
        break;
      case "no-paper":
        root.innerHTML = renderNoPaper();
        break;
      case "not-signed-in":
        root.innerHTML = renderNotSignedIn();
        break;
      case "single-paper":
        root.innerHTML = renderSinglePaper(state.paper, state.check);
        bindSinglePaperEvents();
        break;
      case "multi-paper":
        root.innerHTML = renderMultiPaper(state.papers, state.checks);
        bindMultiPaperEvents();
        break;
      case "already-saved":
        root.innerHTML = renderAlreadySaved(state.paper, state.check);
        bindAlreadySavedEvents();
        break;
      case "saving":
        root.innerHTML = renderSaving();
        break;
      case "success":
        root.innerHTML = renderSuccess(state.savedCount, state.collectionName);
        bindSuccessEvents();
        break;
      case "error":
        root.innerHTML = renderError(state.message);
        bindErrorEvents();
        break;
    }
  }
  function renderLoading() {
    return `
    <div class="popup-header">
      <h1>Save to inCite</h1>
    </div>
    <div class="state-loading">
      <div class="spinner"></div>
      <p>Detecting paper...</p>
    </div>
  `;
  }
  function renderNoPaper() {
    return `
    <div class="popup-header">
      <h1>Save to inCite</h1>
    </div>
    <div class="empty-message">
      <p>No paper detected on this page.</p>
      <p>Try visiting a paper on arXiv, PubMed, Google Scholar, or a journal website.</p>
    </div>
  `;
  }
  function renderNotSignedIn() {
    const url = settings.cloudUrl || "https://inciteref.com";
    return `
    <div class="popup-header">
      <h1>Save to inCite</h1>
    </div>
    <div class="empty-message">
      <p>Sign in to save papers to your library.</p>
      <p><a href="${url}/settings" target="_blank">Set up your API token</a> in the extension settings.</p>
    </div>
  `;
  }
  function renderPaperCard(paper) {
    const authors = paper.authors?.join(", ") ?? "";
    const yearJournal = [paper.year, paper.journal].filter(Boolean).join(" \xB7 ");
    const doi = paper.doi ? `<div class="paper-doi">DOI: ${escapeHtml2(paper.doi)}</div>` : "";
    return `
    <div class="paper-card">
      <div class="paper-title">${escapeHtml2(paper.title)}</div>
      ${authors ? `<div class="paper-authors">${escapeHtml2(authors)}</div>` : ""}
      ${yearJournal ? `<div class="paper-meta">${escapeHtml2(yearJournal)}</div>` : ""}
      ${doi}
    </div>
  `;
  }
  function renderCollectionPicker() {
    const options = collections.map((c) => {
      const selected = c.id === selectedCollectionId ? "selected" : "";
      return `<option value="${escapeHtml2(c.id)}" ${selected}>${escapeHtml2(c.name)}</option>`;
    }).join("");
    return `
    <div class="form-group">
      <label class="form-label">Collection</label>
      <select class="form-select" id="collection-select">
        <option value="">My Library</option>
        ${options}
      </select>
    </div>
  `;
  }
  function renderTagInput() {
    if (!showTagInput) {
      return `<button class="tags-toggle" id="toggle-tags">+ Add tags</button>`;
    }
    const chips = selectedTags.map((t, i) => `
    <span class="tag-chip">
      ${escapeHtml2(t)}
      <button class="tag-chip-remove" data-tag-index="${i}">&times;</button>
    </span>
  `).join("");
    const dropdown = tagSuggestions.length > 0 ? `
    <div class="tag-dropdown" id="tag-dropdown">
      ${tagSuggestions.map((t, i) => `
        <div class="tag-option" data-tag-name="${escapeHtml2(t.name)}" data-index="${i}">${escapeHtml2(t.name)}</div>
      `).join("")}
    </div>
  ` : "";
    return `
    <div class="form-group tag-autocomplete">
      <label class="form-label">Tags</label>
      <div class="tag-input-wrapper" id="tag-wrapper">
        ${chips}
        <input type="text" class="tag-text-input" id="tag-input" placeholder="Type to add..." autocomplete="off">
      </div>
      ${dropdown}
    </div>
  `;
  }
  function renderSinglePaper(paper, _check) {
    return `
    <div class="popup-header">
      <h1>Save to inCite</h1>
    </div>
    <div class="popup-state">
      ${renderPaperCard(paper)}
      ${renderCollectionPicker()}
      ${renderTagInput()}
      <div class="popup-actions">
        <button class="btn-secondary" id="btn-cancel">Cancel</button>
        <button class="btn-primary" id="btn-save">Save</button>
      </div>
    </div>
  `;
  }
  function renderMultiPaper(papers, checks) {
    const saveable = papers.filter((_, i) => !checks[i]?.in_library).length;
    const selected = selectedPaperIndices.size;
    const items = papers.map((p, i) => {
      const inLibrary = checks[i]?.in_library;
      const checked = selectedPaperIndices.has(i) && !inLibrary;
      const cls = inLibrary ? "multi-paper-item in-library" : "multi-paper-item";
      const yearStr = p.year ? ` (${p.year})` : "";
      const badge = inLibrary ? `<span class="multi-paper-badge">In library</span>` : "";
      return `
      <div class="${cls}" data-index="${i}">
        <input type="checkbox" ${checked ? "checked" : ""} ${inLibrary ? "disabled" : ""} data-index="${i}">
        <div class="multi-paper-info">
          <div class="multi-paper-title">${escapeHtml2(p.title)}${yearStr}</div>
          ${p.authors ? `<div class="multi-paper-meta">${escapeHtml2(p.authors.slice(0, 3).join(", "))}${p.authors.length > 3 ? " et al." : ""}</div>` : ""}
        </div>
        ${badge}
      </div>
    `;
    }).join("");
    return `
    <div class="popup-header">
      <h1>Save to inCite</h1>
    </div>
    <div class="popup-state">
      <div class="multi-header">
        <span class="multi-count">${papers.length} papers found</span>
        <button class="btn-select-all" id="btn-select-all">Select all (${saveable})</button>
      </div>
      <div class="multi-paper-list">${items}</div>
      ${renderCollectionPicker()}
      <div class="popup-actions">
        <button class="btn-secondary" id="btn-cancel">Cancel</button>
        <button class="btn-primary" id="btn-save" ${selected === 0 ? "disabled" : ""}>Save ${selected} selected</button>
      </div>
    </div>
  `;
  }
  function renderAlreadySaved(paper, check) {
    const collectionStr = check.collections?.length ? `In: ${check.collections.join(", ")}` : "";
    const tagStr = check.tags?.length ? `Tags: ${check.tags.join(", ")}` : "";
    const url = settings.cloudUrl || "https://inciteref.com";
    return `
    <div class="popup-header">
      <h1>Already in your library</h1>
    </div>
    <div class="popup-state">
      <div class="already-saved">
        <div class="already-saved-title">${escapeHtml2(paper.title)}</div>
        ${collectionStr ? `<div class="already-saved-detail">${escapeHtml2(collectionStr)}</div>` : ""}
        ${tagStr ? `<div class="already-saved-detail">${escapeHtml2(tagStr)}</div>` : ""}
      </div>
      ${renderCollectionPicker()}
      ${renderTagInput()}
      <div class="popup-actions">
        <a href="${url}/library" target="_blank" class="btn-secondary" style="text-decoration: none; text-align: center;">View in Library</a>
        <button class="btn-primary" id="btn-update">Update</button>
        <button class="btn-secondary" id="btn-close">Close</button>
      </div>
    </div>
  `;
  }
  function renderSaving() {
    return `
    <div class="popup-header">
      <h1>Save to inCite</h1>
    </div>
    <div class="state-loading">
      <div class="spinner"></div>
      <p>Saving to library...</p>
    </div>
  `;
  }
  function renderSuccess(savedCount, collectionName) {
    const paperWord = savedCount === 1 ? "paper" : "papers";
    return `
    <div class="popup-header">
      <h1>Saved to inCite</h1>
    </div>
    <div class="success-state">
      <div class="success-icon">&#10003;</div>
      <div class="success-title">${savedCount} ${paperWord} saved</div>
      <div class="success-detail">Added to "${escapeHtml2(collectionName)}"</div>
      <div class="success-hint">This paper will now appear in your recommendations when relevant.</div>
      <div class="popup-actions" style="justify-content: center; margin-top: 16px;">
        <button class="btn-primary" id="btn-done">Done</button>
      </div>
    </div>
  `;
  }
  function renderError(message) {
    return `
    <div class="popup-header">
      <h1>Save to inCite</h1>
    </div>
    <div class="error-state">
      <div class="error-message">${escapeHtml2(message)}</div>
      <div class="popup-actions" style="justify-content: center;">
        <button class="btn-secondary" id="btn-retry">Retry</button>
        <button class="btn-secondary" id="btn-close">Close</button>
      </div>
    </div>
  `;
  }
  function bindSinglePaperEvents() {
    document.getElementById("btn-cancel")?.addEventListener("click", () => window.close());
    document.getElementById("btn-save")?.addEventListener("click", async () => {
      if (state.kind !== "single-paper") return;
      await savePapers([state.paper]);
    });
    bindCollectionEvents();
    bindTagEvents();
  }
  function bindMultiPaperEvents() {
    document.getElementById("btn-cancel")?.addEventListener("click", () => window.close());
    document.getElementById("btn-select-all")?.addEventListener("click", () => {
      if (state.kind !== "multi-paper") return;
      const { papers, checks } = state;
      const allSelected = papers.every((_, i) => checks[i]?.in_library || selectedPaperIndices.has(i));
      if (allSelected) {
        selectedPaperIndices.clear();
      } else {
        papers.forEach((_, i) => {
          if (!checks[i]?.in_library) selectedPaperIndices.add(i);
        });
      }
      render();
    });
    document.querySelectorAll(".multi-paper-item input[type='checkbox']").forEach((cb) => {
      cb.addEventListener("change", () => {
        const index = parseInt(cb.dataset.index, 10);
        if (cb.checked) {
          selectedPaperIndices.add(index);
        } else {
          selectedPaperIndices.delete(index);
        }
        const btn = document.getElementById("btn-save");
        if (btn) {
          btn.textContent = `Save ${selectedPaperIndices.size} selected`;
          btn.disabled = selectedPaperIndices.size === 0;
        }
      });
    });
    document.querySelectorAll(".multi-paper-item:not(.in-library)").forEach((row) => {
      row.addEventListener("click", (e) => {
        if (e.target.tagName === "INPUT") return;
        const cb = row.querySelector("input[type='checkbox']");
        cb.checked = !cb.checked;
        cb.dispatchEvent(new Event("change"));
      });
    });
    document.getElementById("btn-save")?.addEventListener("click", async () => {
      if (state.kind !== "multi-paper") return;
      const papersToSave = state.papers.filter((_, i) => selectedPaperIndices.has(i));
      if (papersToSave.length === 0) return;
      await savePapers(papersToSave);
    });
    bindCollectionEvents();
  }
  function bindAlreadySavedEvents() {
    document.getElementById("btn-close")?.addEventListener("click", () => window.close());
    document.getElementById("btn-update")?.addEventListener("click", async () => {
      if (state.kind !== "already-saved") return;
      const canonicalId = state.check.canonical_id;
      if (!canonicalId) return;
      state = { kind: "saving" };
      render();
      try {
        const response = await chrome.runtime.sendMessage({
          type: "UPDATE_LIBRARY_ITEM",
          canonicalId,
          collectionId: selectedCollectionId,
          tags: selectedTags.length > 0 ? selectedTags : void 0
        });
        if (response?.error) {
          state = { kind: "error", message: response.error };
        } else {
          const collectionName = collections.find((c) => c.id === selectedCollectionId)?.name ?? "My Library";
          state = { kind: "success", savedCount: 1, collectionName };
        }
      } catch (err) {
        state = { kind: "error", message: err instanceof Error ? err.message : "Update failed" };
      }
      render();
      if (state.kind === "success") {
        setTimeout(() => window.close(), 1500);
      }
    });
    bindCollectionEvents();
    bindTagEvents();
  }
  function bindSuccessEvents() {
    document.getElementById("btn-done")?.addEventListener("click", () => window.close());
  }
  function bindErrorEvents() {
    document.getElementById("btn-retry")?.addEventListener("click", () => {
      state = { kind: "loading" };
      render();
      location.reload();
    });
    document.getElementById("btn-close")?.addEventListener("click", () => window.close());
  }
  function bindCollectionEvents() {
    document.getElementById("collection-select")?.addEventListener("change", (e) => {
      const select = e.target;
      selectedCollectionId = select.value || null;
      chrome.storage.local.set({ lastCollectionId: selectedCollectionId });
    });
  }
  function bindTagEvents() {
    const toggleBtn = document.getElementById("toggle-tags");
    if (toggleBtn) {
      toggleBtn.addEventListener("click", () => {
        showTagInput = true;
        render();
        document.getElementById("tag-input")?.focus();
      });
    }
    const tagInput = document.getElementById("tag-input");
    if (tagInput) {
      tagInput.addEventListener("input", async () => {
        const query = tagInput.value.trim();
        if (query.length < 1) {
          tagSuggestions = [];
          render();
          document.getElementById("tag-input")?.focus();
          return;
        }
        try {
          const resp = await chrome.runtime.sendMessage({ type: "SEARCH_TAGS", query });
          tagSuggestions = (resp?.tags ?? []).filter(
            (t) => !selectedTags.includes(t.name)
          );
        } catch {
          tagSuggestions = [];
        }
        render();
        const newInput = document.getElementById("tag-input");
        if (newInput) {
          newInput.value = query;
          newInput.focus();
          newInput.setSelectionRange(query.length, query.length);
        }
      });
      tagInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === ",") {
          e.preventDefault();
          const val = tagInput.value.trim().replace(/,$/, "");
          if (val && !selectedTags.includes(val)) {
            selectedTags.push(val);
            tagSuggestions = [];
            render();
            document.getElementById("tag-input")?.focus();
          }
        }
      });
    }
    document.querySelectorAll(".tag-option").forEach((opt) => {
      opt.addEventListener("click", () => {
        const name = opt.dataset.tagName;
        if (!selectedTags.includes(name)) {
          selectedTags.push(name);
          tagSuggestions = [];
          render();
          document.getElementById("tag-input")?.focus();
        }
      });
    });
    document.querySelectorAll(".tag-chip-remove").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.dataset.tagIndex, 10);
        selectedTags.splice(idx, 1);
        render();
      });
    });
  }
  async function savePapers(papers) {
    state = { kind: "saving" };
    render();
    try {
      const response = await chrome.runtime.sendMessage({
        type: "SAVE_PAPERS",
        papers,
        collectionId: selectedCollectionId,
        tags: selectedTags.length > 0 ? selectedTags : void 0,
        enrich: true
      });
      if (response?.error) {
        state = { kind: "error", message: response.error };
      } else {
        const savedCount = (response?.saved?.length ?? 0) + (response?.already_existed?.length ?? 0);
        const collectionName = collections.find((c) => c.id === selectedCollectionId)?.name ?? "My Library";
        state = { kind: "success", savedCount, collectionName };
      }
    } catch (err) {
      state = { kind: "error", message: err instanceof Error ? err.message : "Save failed" };
    }
    render();
    if (state.kind === "success") {
      setTimeout(() => window.close(), 1500);
    }
  }
  function escapeHtml2(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
})();
//# sourceMappingURL=popup.js.map

"use strict";
(() => {
  // src/content/overleaf-main.ts
  function getEditorView() {
    const cmEditor = document.querySelector(".cm-editor");
    if (!cmEditor) return null;
    const cmView = cmEditor.cmView;
    if (cmView?.view) return cmView.view;
    const cmContent = document.querySelector(".cm-content");
    if (cmContent) {
      let el = cmContent;
      while (el && el !== document.body) {
        const view = el.cmView;
        if (view?.view) return view.view;
        el = el.parentElement;
      }
    }
    const win = window;
    for (const key of ["_ide", "editor"]) {
      const global = win[key];
      if (global) {
        const view = global.editorManager?.currentView ?? global.editorView ?? global.view;
        if (view && typeof view.state?.doc?.toString === "function") {
          return view;
        }
      }
    }
    return null;
  }
  function getSelectionFallback() {
    const selection = window.getSelection();
    const text = selection?.toString().trim();
    return text && text.length > 0 ? text : null;
  }
  var editorReady = false;
  var retryCount = 0;
  var MAX_RETRIES = 10;
  var RETRY_INTERVAL = 1e3;
  function waitForEditor() {
    if (editorReady || retryCount >= MAX_RETRIES) return;
    retryCount++;
    const view = getEditorView();
    if (view) {
      editorReady = true;
      return;
    }
    setTimeout(waitForEditor, RETRY_INTERVAL);
  }
  waitForEditor();
  var observer = new MutationObserver(() => {
    if (!editorReady && getEditorView()) {
      editorReady = true;
      observer.disconnect();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
  setTimeout(() => observer.disconnect(), 3e4);
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "incite-isolated") return;
    const { type, requestId, payload } = data;
    if (type === "GET_CONTEXT") {
      handleGetContext(requestId);
    } else if (type === "INSERT_CITATION") {
      handleInsertCitation(requestId, payload?.citation);
    }
  });
  function handleGetContext(requestId) {
    const view = getEditorView();
    if (view) {
      const { from, to, head } = view.state.selection.main;
      if (from !== to) {
        const text = view.state.doc.sliceString(from, to);
        respond(requestId, "CONTEXT_RESPONSE", {
          type: "CONTEXT_RESPONSE",
          requestId,
          text
        });
      } else {
        const fullText = view.state.doc.toString();
        respond(requestId, "CONTEXT_RESPONSE", {
          type: "CONTEXT_RESPONSE",
          requestId,
          fullText,
          cursorOffset: head
        });
      }
      return;
    }
    const fallbackText = getSelectionFallback();
    if (fallbackText) {
      respond(requestId, "CONTEXT_RESPONSE", {
        type: "CONTEXT_RESPONSE",
        requestId,
        text: fallbackText
      });
      return;
    }
    respond(requestId, "CONTEXT_RESPONSE", {
      type: "CONTEXT_RESPONSE",
      requestId,
      error: "Could not find Overleaf editor. Make sure a document is open. If the issue persists, select text and use the manual input in the panel."
    });
  }
  function handleInsertCitation(requestId, citation) {
    const view = getEditorView();
    if (!view || !citation) {
      respond(requestId, "INSERT_RESULT", { success: false });
      return;
    }
    const cursor = view.state.selection.main.head;
    view.dispatch({
      changes: { from: cursor, insert: citation }
    });
    respond(requestId, "INSERT_RESULT", { success: true, method: "direct" });
  }
  function respond(requestId, type, payload) {
    window.postMessage(
      {
        source: "incite-main",
        type,
        requestId,
        payload
      },
      "*"
    );
  }
})();
//# sourceMappingURL=overleaf-main.js.map

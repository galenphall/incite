"use strict";
(() => {
  // ../shared/src/citation-tracker.ts
  function recommendationToTracked(rec) {
    return {
      paper_id: rec.paper_id,
      bibtex_key: rec.bibtex_key ?? rec.paper_id,
      title: rec.title,
      authors: rec.authors ?? [],
      year: rec.year,
      doi: rec.doi,
      journal: rec.journal,
      abstract: rec.abstract,
      insertedAt: Date.now()
    };
  }
  var CitationTracker = class {
    constructor(storage, docKey) {
      this.citations = [];
      this.storage = storage;
      this.docKey = docKey;
    }
    /** Load tracked citations from storage. */
    async load() {
      this.citations = await this.storage.load(this.docKey);
    }
    /** Track one or more citations after insertion. Persists immediately. */
    async track(recs) {
      for (const rec of recs) {
        if (!this.isTracked(rec.paper_id)) {
          this.citations.push(recommendationToTracked(rec));
        }
      }
      await this.storage.save(this.docKey, this.citations);
    }
    /** Remove a tracked citation by paper ID. */
    async remove(paperId) {
      this.citations = this.citations.filter((c) => c.paper_id !== paperId);
      await this.storage.save(this.docKey, this.citations);
    }
    /** Get all tracked citations sorted by insertion time. */
    getAll() {
      return [...this.citations].sort((a, b) => a.insertedAt - b.insertedAt);
    }
    /** Check whether a paper has already been cited. */
    isTracked(paperId) {
      return this.citations.some((c) => c.paper_id === paperId);
    }
    /** Number of tracked citations. */
    get count() {
      return this.citations.length;
    }
  };

  // ../shared/src/bibliography.ts
  var LATEX_SPECIAL = {
    "\\": "\\textbackslash{}",
    "{": "\\{",
    "}": "\\}",
    "&": "\\&",
    "%": "\\%",
    "#": "\\#",
    _: "\\_",
    "~": "\\textasciitilde{}",
    "^": "\\textasciicircum{}"
  };
  function escapeLaTeX(text) {
    let result = "";
    for (const ch of text) {
      result += LATEX_SPECIAL[ch] ?? ch;
    }
    return result;
  }
  function formatBibTeXEntry(cite) {
    const key = cite.bibtex_key || cite.paper_id;
    const fields = [];
    fields.push(`  title = {${escapeLaTeX(cite.title)}}`);
    if (cite.authors.length > 0) {
      fields.push(`  author = {${escapeLaTeX(cite.authors.join(" and "))}}`);
    }
    if (cite.year != null) {
      fields.push(`  year = {${cite.year}}`);
    }
    if (cite.journal) {
      fields.push(`  journal = {${escapeLaTeX(cite.journal)}}`);
    }
    if (cite.doi) {
      fields.push(`  doi = {${cite.doi}}`);
    }
    if (cite.abstract) {
      fields.push(`  abstract = {${escapeLaTeX(cite.abstract)}}`);
    }
    return `@article{${key},
${fields.join(",\n")}
}`;
  }
  function exportBibTeX(citations) {
    return citations.map(formatBibTeXEntry).join("\n\n");
  }
  function formatRISEntry(cite) {
    const lines = [];
    lines.push("TY  - JOUR");
    lines.push(`TI  - ${cite.title}`);
    for (const author of cite.authors) {
      lines.push(`AU  - ${author}`);
    }
    if (cite.year != null) {
      lines.push(`PY  - ${cite.year}`);
    }
    if (cite.doi) {
      lines.push(`DO  - ${cite.doi}`);
    }
    if (cite.journal) {
      lines.push(`JO  - ${cite.journal}`);
    }
    if (cite.abstract) {
      lines.push(`AB  - ${cite.abstract}`);
    }
    lines.push("ER  - ");
    return lines.join("\n");
  }
  function exportRIS(citations) {
    return citations.map(formatRISEntry).join("\n\n");
  }
  function getLastName(author) {
    if (author.includes(",")) {
      return author.split(",")[0].trim();
    }
    const parts = author.trim().split(/\s+/);
    return parts[parts.length - 1];
  }
  function formatAPAEntry(cite) {
    const parts = [];
    if (cite.authors.length > 0) {
      if (cite.authors.length <= 2) {
        parts.push(cite.authors.map(getLastName).join(" & "));
      } else {
        const lastNames = cite.authors.map(getLastName);
        const allButLast = lastNames.slice(0, -1).join(", ");
        parts.push(`${allButLast}, & ${lastNames[lastNames.length - 1]}`);
      }
    }
    parts.push(cite.year != null ? `(${cite.year}).` : "(n.d.).");
    parts.push(`${cite.title}.`);
    if (cite.journal) {
      parts.push(`${cite.journal}.`);
    }
    if (cite.doi) {
      parts.push(`https://doi.org/${cite.doi}`);
    }
    return parts.join(" ");
  }
  function exportFormattedText(citations) {
    const sorted = [...citations].sort((a, b) => {
      const aName = a.authors.length > 0 ? getLastName(a.authors[0]) : "";
      const bName = b.authors.length > 0 ? getLastName(b.authors[0]) : "";
      return aName.localeCompare(bName);
    });
    return sorted.map(formatAPAEntry).join("\n\n");
  }

  // ../shared/src/ui-helpers.ts
  var DEFAULT_CLASS_MAP = {
    resultCard: "incite-result-card",
    resultHeader: "incite-result-header",
    resultHeaderLeft: "incite-result-header-left",
    selectCheckbox: "incite-select-checkbox",
    rankBadge: "incite-rank-badge",
    citedBadge: "incite-cited-badge",
    confidenceBadge: "incite-confidence-badge",
    confidenceHigh: "incite-confidence-high",
    confidenceMid: "incite-confidence-mid",
    confidenceLow: "incite-confidence-low",
    resultTitle: "incite-result-title",
    resultMeta: "incite-result-meta",
    evidence: "incite-evidence",
    evidenceSecondary: "incite-evidence-secondary",
    evidenceScore: "incite-evidence-score",
    resultAbstract: "incite-result-abstract",
    resultActions: "incite-result-actions",
    insertBtn: "incite-insert-btn",
    copyBtn: "incite-copy-btn",
    bibSection: "incite-bibliography-section",
    bibToggle: "incite-bib-toggle",
    bibContent: "incite-bib-content",
    bibExportBar: "incite-bib-export-bar",
    bibList: "incite-bib-list",
    bibItem: "incite-bib-item",
    bibItemText: "incite-bib-item-text",
    bibItemAuthors: "incite-bib-item-authors",
    bibItemTitle: "incite-bib-item-title",
    bibRemove: "incite-bib-remove"
  };
  function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function escapeAttr(text) {
    return text.replace(/&/g, "&amp;").replace(/'/g, "&#39;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function confidenceLevel(score) {
    if (score >= 0.55) return "high";
    if (score >= 0.35) return "mid";
    return "low";
  }
  function renderHighlightedTextHTML(text, maxLength) {
    const startBold = text.indexOf("**");
    const endBold = text.indexOf("**", startBold + 2);
    if (startBold === -1 || endBold === -1) {
      const truncated = text.length > maxLength;
      return escapeHtml(truncated ? text.slice(0, maxLength) + "..." : text);
    }
    const highlightEnd = endBold + 2;
    const highlightLength = highlightEnd - startBold;
    const available = maxLength - highlightLength;
    const ctxBefore = Math.floor(available * 0.3);
    const ctxAfter = available - ctxBefore;
    const sliceStart = Math.max(0, startBold - ctxBefore);
    const sliceEnd = Math.min(text.length, highlightEnd + ctxAfter);
    let display = text.slice(sliceStart, sliceEnd);
    if (sliceStart > 0) {
      const spaceIdx = display.indexOf(" ");
      if (spaceIdx > 0 && spaceIdx < 20) {
        display = display.slice(spaceIdx + 1);
      }
      display = "..." + display;
    }
    if (sliceEnd < text.length) {
      display = display + "...";
    }
    const parts = display.split(/(\*\*.+?\*\*)/g);
    let html = "";
    for (const part of parts) {
      if (part.startsWith("**") && part.endsWith("**")) {
        html += `<strong>${escapeHtml(part.slice(2, -2))}</strong>`;
      } else if (part) {
        html += escapeHtml(part);
      }
    }
    return html;
  }
  function renderEvidenceHTML(rec, options, cm = {}) {
    const c = { ...DEFAULT_CLASS_MAP, ...cm };
    if (!options.showParagraphs) return "";
    let html = "";
    if (rec.matched_paragraphs && rec.matched_paragraphs.length > 0) {
      for (let i = 0; i < rec.matched_paragraphs.length; i++) {
        const snippet = rec.matched_paragraphs[i];
        const cls = i === 0 ? c.evidence : `${c.evidence} ${c.evidenceSecondary}`;
        const badge = snippet.score != null ? `<span class="${c.evidenceScore}">${Math.round(snippet.score * 100)}%</span> ` : "";
        html += `<div class="${cls}">${badge}${renderHighlightedTextHTML(snippet.text, 300)}</div>`;
      }
    } else if (rec.matched_paragraph) {
      html += `<div class="${c.evidence}">${renderHighlightedTextHTML(rec.matched_paragraph, 300)}</div>`;
    }
    return html;
  }
  function renderResultCardHTML(rec, options, cm = {}) {
    const c = { ...DEFAULT_CLASS_MAP, ...cm };
    const confidence = rec.confidence ?? rec.score;
    const level = confidenceLevel(confidence);
    const confClass = level === "high" ? c.confidenceHigh : level === "mid" ? c.confidenceMid : c.confidenceLow;
    const confLabel = `${Math.round(confidence * 100)}%`;
    let html = `<div class="${c.resultCard}">`;
    html += `<div class="${c.resultHeader}">`;
    html += `<div class="${c.resultHeaderLeft}">`;
    html += `<input type="checkbox" class="${c.selectCheckbox}" data-action="select" data-rec='${escapeAttr(JSON.stringify(rec))}' />`;
    html += `<span class="${c.rankBadge}">#${rec.rank}</span>`;
    if (options.isCited) {
      html += `<span class="${c.citedBadge}">Cited</span>`;
    }
    html += `</div>`;
    html += `<span class="${c.confidenceBadge} ${confClass}">${confLabel}</span>`;
    html += `</div>`;
    html += `<div class="${c.resultTitle}">${escapeHtml(rec.title)}</div>`;
    const meta = [];
    if (rec.authors && rec.authors.length > 0) {
      const names = rec.authors.slice(0, 3).join(", ");
      meta.push(rec.authors.length > 3 ? names + " et al." : names);
    }
    if (rec.year) meta.push(`(${rec.year})`);
    if (meta.length > 0) {
      html += `<div class="${c.resultMeta}">${escapeHtml(meta.join(" "))}</div>`;
    }
    html += renderEvidenceHTML(rec, options, cm);
    if (options.showAbstracts && rec.abstract) {
      html += `<div class="${c.resultAbstract}">${escapeHtml(rec.abstract)}</div>`;
    }
    const recJson = escapeAttr(JSON.stringify(rec));
    const bibtexKey = rec.bibtex_key ?? rec.paper_id;
    html += `<div class="${c.resultActions}">`;
    html += `<button class="${c.insertBtn}" data-action="insert" data-rec='${recJson}'>Insert</button>`;
    html += `<button class="${c.copyBtn}" data-action="copy" data-copy="${escapeAttr(bibtexKey)}">Copy Key</button>`;
    html += `</div>`;
    html += `</div>`;
    return html;
  }
  function renderBibliographyHTML(citations, cm = {}) {
    const c = { ...DEFAULT_CLASS_MAP, ...cm };
    let html = `<div class="${c.bibSection}">`;
    html += `<button class="${c.bibToggle}">`;
    html += `Bibliography (${citations.length} citation${citations.length !== 1 ? "s" : ""})`;
    html += `<span class="toggle-arrow">&#9662;</span>`;
    html += `</button>`;
    html += `<div class="${c.bibContent}" style="display:none;">`;
    html += `<div class="${c.bibExportBar}">`;
    html += `<button class="${c.copyBtn}" data-action="bib-export" data-format="bibtex">BibTeX</button>`;
    html += `<button class="${c.copyBtn}" data-action="bib-export" data-format="ris">RIS</button>`;
    html += `<button class="${c.copyBtn}" data-action="bib-export" data-format="apa">APA</button>`;
    html += `</div>`;
    html += `<div class="${c.bibList}">`;
    for (const cite of citations) {
      const authorStr = cite.authors.length > 0 ? cite.authors.length > 2 ? cite.authors[0].split(" ").pop() + " et al." : cite.authors.map((a) => a.split(" ").pop()).join(" & ") : "";
      const yearStr = cite.year != null ? ` (${cite.year})` : "";
      html += `<div class="${c.bibItem}" data-paper-id="${escapeAttr(cite.paper_id)}">`;
      html += `<div class="${c.bibItemText}">`;
      html += `<span class="${c.bibItemAuthors}">${escapeHtml(authorStr + yearStr)}</span> `;
      html += `<span class="${c.bibItemTitle}">${escapeHtml(cite.title)}</span>`;
      html += `</div>`;
      html += `<button class="${c.bibRemove}" data-action="bib-remove" data-paper-id="${escapeAttr(cite.paper_id)}" title="Remove">&times;</button>`;
      html += `</div>`;
    }
    html += `</div>`;
    html += `</div>`;
    html += `</div>`;
    return html;
  }

  // src/shared/citation-storage.ts
  function extractDocId(url) {
    const gdocsMatch = url.match(/docs\.google\.com\/document\/d\/([^/]+)/);
    if (gdocsMatch) return `gdocs:${gdocsMatch[1]}`;
    const overleafMatch = url.match(/overleaf\.com\/project\/([^/?#]+)/);
    if (overleafMatch) return `overleaf:${overleafMatch[1]}`;
    return null;
  }
  var ChromeCitationStorage = class {
    prefix = "incite_citations_";
    async load(docKey) {
      const key = this.prefix + docKey;
      const result = await chrome.storage.local.get(key);
      return result[key] ?? [];
    }
    async save(docKey, citations) {
      const key = this.prefix + docKey;
      await chrome.storage.local.set({ [key]: citations });
    }
  };
  async function getDocKeyFromActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return null;
    return extractDocId(tab.url);
  }

  // src/panel/panel.ts
  var CHROME_CLASS_MAP = {
    resultCard: "result-card",
    resultHeader: "result-header",
    resultHeaderLeft: "result-header-left",
    selectCheckbox: "select-checkbox",
    rankBadge: "rank-badge",
    citedBadge: "cited-badge",
    confidenceBadge: "confidence-badge",
    confidenceHigh: "confidence-high",
    confidenceMid: "confidence-medium",
    confidenceLow: "confidence-low",
    resultTitle: "result-title",
    resultMeta: "result-meta",
    evidence: "evidence",
    evidenceSecondary: "evidence-secondary",
    evidenceScore: "evidence-score",
    resultAbstract: "result-abstract",
    resultActions: "result-actions",
    insertBtn: "btn-small btn-insert",
    copyBtn: "btn-small",
    bibSection: "bibliography-section",
    bibToggle: "bib-toggle",
    bibContent: "bib-content",
    bibExportBar: "bib-export-bar",
    bibList: "bib-list",
    bibItem: "bib-item",
    bibItemText: "bib-item-text",
    bibItemAuthors: "bib-item-authors",
    bibItemTitle: "bib-item-title",
    bibRemove: "bib-remove"
  };
  var isLoading = false;
  var selectedRecs = /* @__PURE__ */ new Map();
  var tracker = null;
  var panelSettings = {
    showParagraphs: true,
    showAbstracts: false
  };
  async function loadPanelSettings() {
    try {
      const response = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
      if (response?.settings) {
        panelSettings = {
          showParagraphs: response.settings.showParagraphs ?? true,
          showAbstracts: response.settings.showAbstracts ?? false
        };
      }
    } catch (err) {
      console.error("Failed to load panel settings:", err);
    }
  }
  var content = document.getElementById("content");
  var btnRecommend = document.getElementById("btn-recommend");
  var statusDot = document.getElementById("status-dot");
  var manualInput = document.getElementById("manual-input");
  var btnToggleManual = document.getElementById("btn-toggle-manual");
  var manualText = document.getElementById("manual-text");
  var btnManualSubmit = document.getElementById("btn-manual-submit");
  btnRecommend.addEventListener("click", () => getRecommendations());
  btnToggleManual.addEventListener("click", () => {
    manualInput.classList.toggle("collapsed");
    if (!manualInput.classList.contains("collapsed")) {
      manualText.focus();
    }
  });
  btnManualSubmit.addEventListener("click", () => {
    const text = manualText.value.trim();
    if (text.length > 0) {
      getRecommendationsForText(text);
    }
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "TRIGGER_FROM_HOTKEY") {
      getRecommendations();
      sendResponse({ ack: true });
    }
    return false;
  });
  chrome.runtime.sendMessage({ type: "PANEL_READY" }).catch((err) => {
    console.error("PANEL_READY message failed:", err);
  });
  checkHealth();
  loadPanelSettings();
  initTracker();
  async function initTracker() {
    const docKey = await getDocKeyFromActiveTab();
    if (!docKey) return;
    const storage = new ChromeCitationStorage();
    tracker = new CitationTracker(storage, docKey);
    await tracker.load();
    renderBibliography();
  }
  async function getRecommendations() {
    if (isLoading) return;
    isLoading = true;
    btnRecommend.disabled = true;
    showLoading();
    try {
      const response = await chrome.runtime.sendMessage({ type: "GET_RECOMMENDATIONS" });
      if (response?.error) {
        showExtractionError(response.error);
      } else if (response?.response) {
        await showResults(response.response);
      } else {
        showError("Unexpected response from service worker.");
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      showError(message);
    } finally {
      isLoading = false;
      btnRecommend.disabled = false;
    }
  }
  async function getRecommendationsForText(text) {
    if (isLoading) return;
    isLoading = true;
    btnManualSubmit.disabled = true;
    btnRecommend.disabled = true;
    showLoading();
    try {
      const response = await chrome.runtime.sendMessage({ type: "GET_RECOMMENDATIONS_FOR_TEXT", text });
      if (response?.error) {
        showError(response.error);
      } else if (response?.response) {
        await showResults(response.response);
      } else {
        showError("Unexpected response from service worker.");
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      showError(message);
    } finally {
      isLoading = false;
      btnManualSubmit.disabled = false;
      btnRecommend.disabled = false;
    }
  }
  async function checkHealth() {
    try {
      const response = await chrome.runtime.sendMessage({ type: "CHECK_HEALTH" });
      if (response?.response) {
        statusDot.className = "status-dot connected";
        statusDot.title = `Connected -- ${response.response.corpus_size ?? "?"} papers`;
      } else {
        statusDot.className = "status-dot error";
        statusDot.title = response?.error ?? "Not connected";
      }
    } catch {
      statusDot.className = "status-dot error";
      statusDot.title = "Not connected";
    }
  }
  function showLoading() {
    content.innerHTML = `
    <div class="loading">
      <div class="spinner"></div>
      <p>Searching your library...</p>
    </div>
  `;
  }
  function showError(message) {
    content.innerHTML = `<div class="error-state">${escapeHtml(message)}</div>`;
  }
  function showExtractionError(message) {
    content.innerHTML = `<div class="error-state">${escapeHtml(message)}</div>`;
    manualInput.classList.remove("collapsed");
    manualText.focus();
  }
  async function showResults(response) {
    await loadPanelSettings();
    const recs = response.recommendations;
    selectedRecs.clear();
    if (!recs || recs.length === 0) {
      content.innerHTML = `<div class="empty-state"><p>No matching papers found.</p></div>`;
      return;
    }
    let html = "";
    if (response.timing?.total_ms) {
      html += `<div class="timing">${recs.length} results in ${Math.round(response.timing.total_ms)}ms -- ${response.corpus_size} papers</div>`;
    }
    html += `<div id="selection-bar" class="selection-bar" style="display:none;">`;
    html += `<span id="selection-count">0 selected</span>`;
    html += `<button id="btn-insert-selected" class="btn-small btn-insert">Insert Selected</button>`;
    html += `<button id="btn-clear-selected" class="btn-small">Clear</button>`;
    html += `</div>`;
    for (const rec of recs) {
      const isCited = tracker?.isTracked(rec.paper_id) ?? false;
      html += renderResultCardHTML(rec, {
        showParagraphs: panelSettings.showParagraphs,
        showAbstracts: panelSettings.showAbstracts,
        isCited
      }, CHROME_CLASS_MAP);
    }
    content.innerHTML = html;
    manualInput.classList.add("collapsed");
    content.querySelectorAll("[data-action='insert']").forEach((btn) => {
      btn.addEventListener("click", () => {
        const recData = btn.getAttribute("data-rec");
        if (recData) {
          const recommendation = JSON.parse(recData);
          insertCitation(recommendation);
        }
      });
    });
    content.querySelectorAll("[data-action='copy']").forEach((btn) => {
      btn.addEventListener("click", () => {
        const text = btn.getAttribute("data-copy");
        if (text) {
          navigator.clipboard.writeText(text).then(() => showToast("Copied!"));
        }
      });
    });
    content.querySelectorAll("[data-action='select']").forEach((cb) => {
      cb.addEventListener("change", () => {
        const recData = cb.getAttribute("data-rec");
        if (!recData) return;
        const rec = JSON.parse(recData);
        if (cb.checked) {
          selectedRecs.set(rec.paper_id, rec);
        } else {
          selectedRecs.delete(rec.paper_id);
        }
        updateSelectionBar();
      });
    });
    document.getElementById("btn-insert-selected")?.addEventListener("click", () => {
      insertMultiCitation();
    });
    document.getElementById("btn-clear-selected")?.addEventListener("click", () => {
      selectedRecs.clear();
      content.querySelectorAll("[data-action='select']").forEach((cb) => {
        cb.checked = false;
      });
      updateSelectionBar();
    });
    renderBibliography();
  }
  function updateSelectionBar() {
    const bar = document.getElementById("selection-bar");
    const count = document.getElementById("selection-count");
    if (!bar || !count) return;
    if (selectedRecs.size > 0) {
      bar.style.display = "flex";
      count.textContent = `${selectedRecs.size} selected`;
      content.classList.add("has-selection");
    } else {
      bar.style.display = "none";
      content.classList.remove("has-selection");
    }
  }
  async function insertCitation(rec) {
    try {
      const response = await chrome.runtime.sendMessage({
        type: "INSERT_CITATION_REQUEST",
        recommendation: rec
      });
      if (response?.success === false) {
        showToast("Could not insert -- copied to clipboard");
        const key = rec.bibtex_key ?? rec.paper_id;
        await navigator.clipboard.writeText(key);
      } else if (response?.method === "clipboard") {
        showToast("Copied -- paste with Cmd/Ctrl+V");
      } else {
        showToast("Citation inserted");
      }
      if (tracker) {
        await tracker.track([rec]);
        refreshCitedBadges();
        renderBibliography();
      }
    } catch {
      showToast("Insert failed");
    }
  }
  async function insertMultiCitation() {
    const recs = Array.from(selectedRecs.values());
    if (recs.length === 0) return;
    try {
      const response = await chrome.runtime.sendMessage({
        type: "INSERT_MULTI_CITATION_REQUEST",
        recommendations: recs
      });
      if (response?.success === false) {
        showToast("Could not insert -- copied to clipboard");
      } else if (response?.method === "clipboard") {
        showToast(`${recs.length} citations copied -- paste with Cmd/Ctrl+V`);
      } else {
        showToast(`${recs.length} citations inserted`);
      }
      if (tracker) {
        await tracker.track(recs);
        refreshCitedBadges();
        renderBibliography();
      }
      selectedRecs.clear();
      content.querySelectorAll("[data-action='select']").forEach((cb) => {
        cb.checked = false;
      });
      updateSelectionBar();
    } catch {
      showToast("Insert failed");
    }
  }
  function refreshCitedBadges() {
    if (!tracker) return;
    content.querySelectorAll("[data-action='select']").forEach((cb) => {
      const recData = cb.getAttribute("data-rec");
      if (!recData) return;
      const rec = JSON.parse(recData);
      const card = cb.closest(".result-card");
      if (!card) return;
      const headerLeft = card.querySelector(".result-header-left");
      if (!headerLeft) return;
      const existingBadge = headerLeft.querySelector(".cited-badge");
      if (tracker.isTracked(rec.paper_id) && !existingBadge) {
        const badge = document.createElement("span");
        badge.className = "cited-badge";
        badge.textContent = "Cited";
        headerLeft.appendChild(badge);
      }
    });
  }
  function renderBibliography() {
    document.getElementById("bibliography-section")?.remove();
    if (!tracker || tracker.count === 0) return;
    const citations = tracker.getAll();
    const bibHtml = renderBibliographyHTML(citations, CHROME_CLASS_MAP);
    const wrapper = document.createElement("div");
    wrapper.id = "bibliography-section";
    wrapper.innerHTML = bibHtml;
    const bibElement = wrapper.firstElementChild;
    document.body.appendChild(bibElement);
    bibElement.querySelector(`.${CHROME_CLASS_MAP.bibToggle}`)?.addEventListener("click", () => {
      const bibContent = bibElement.querySelector(`.${CHROME_CLASS_MAP.bibContent}`);
      const toggle = bibElement.querySelector(`.${CHROME_CLASS_MAP.bibToggle}`);
      if (!bibContent || !toggle) return;
      const isVisible = bibContent.style.display !== "none";
      bibContent.style.display = isVisible ? "none" : "block";
      toggle.classList.toggle("expanded", !isVisible);
    });
    bibElement.querySelectorAll("[data-action='bib-export']").forEach((btn) => {
      btn.addEventListener("click", () => {
        const format = btn.getAttribute("data-format");
        if (!tracker) return;
        const allCitations = tracker.getAll();
        if (format === "bibtex") {
          const text = exportBibTeX(allCitations);
          copyAndDownload(text, "references.bib", "BibTeX copied & downloaded");
        } else if (format === "ris") {
          const text = exportRIS(allCitations);
          copyAndDownload(text, "references.ris", "RIS copied & downloaded");
        } else if (format === "apa") {
          const text = exportFormattedText(allCitations);
          navigator.clipboard.writeText(text).then(() => showToast("APA text copied"));
        }
      });
    });
    bibElement.querySelectorAll("[data-action='bib-remove']").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const paperId = btn.getAttribute("data-paper-id");
        if (!paperId || !tracker) return;
        await tracker.remove(paperId);
        refreshCitedBadges();
        renderBibliography();
      });
    });
  }
  function copyAndDownload(text, filename, toastMsg) {
    navigator.clipboard.writeText(text).then(() => {
      const blob = new Blob([text], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
      showToast(toastMsg);
    });
  }
  function showToast(message) {
    const existing = document.querySelector(".toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  }
})();
//# sourceMappingURL=panel.js.map

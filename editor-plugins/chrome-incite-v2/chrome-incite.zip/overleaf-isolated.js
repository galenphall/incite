"use strict";
(() => {
  // src/content/shared.ts
  function showToast(message, duration = 3e3) {
    const existing = document.getElementById("incite-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "incite-toast";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      padding: "10px 18px",
      background: "#1a1a2e",
      color: "#fff",
      borderRadius: "8px",
      fontSize: "13px",
      zIndex: "999999",
      boxShadow: "0 4px 12px rgba(0,0,0,0.15)"
    });
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), duration);
  }

  // src/content/overleaf-isolated.ts
  var pendingRequests = /* @__PURE__ */ new Map();
  var BRIDGE_TIMEOUT_MS = 1e4;
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "GET_CONTEXT" || message.type === "INSERT_CITATION") {
      sendWithRetry(message, sendResponse);
      return true;
    }
  });
  function sendWithRetry(message, sendResponse, isRetry = false) {
    const requestId = message.requestId ?? crypto.randomUUID();
    window.postMessage(
      {
        source: "incite-isolated",
        type: message.type,
        requestId,
        payload: message
      },
      "*"
    );
    const timeout = setTimeout(() => {
      pendingRequests.delete(requestId);
      if (!isRetry) {
        sendWithRetry(message, sendResponse, true);
        return;
      }
      if (message.type === "GET_CONTEXT") {
        sendResponse({
          type: "CONTEXT_RESPONSE",
          requestId,
          error: "Overleaf editor did not respond. Try refreshing the page, or use the manual text input in the panel."
        });
      } else {
        sendResponse({ type: "INSERT_RESULT", success: false });
      }
    }, BRIDGE_TIMEOUT_MS);
    pendingRequests.set(requestId, (response) => {
      clearTimeout(timeout);
      sendResponse(response);
    });
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "incite-main") return;
    const resolve = pendingRequests.get(data.requestId);
    if (resolve) {
      pendingRequests.delete(data.requestId);
      if (data.type === "CONTEXT_RESPONSE") {
        resolve(data.payload);
      } else if (data.type === "INSERT_RESULT") {
        if (data.payload?.success) {
          showToast("Citation inserted");
        }
        resolve(data.payload);
      }
    }
  });
})();
//# sourceMappingURL=overleaf-isolated.js.map

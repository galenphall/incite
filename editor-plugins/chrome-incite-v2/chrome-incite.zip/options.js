"use strict";
(() => {
  // ../shared/src/types.ts
  var DEFAULT_SETTINGS = {
    apiMode: "cloud",
    cloudUrl: "https://inciteref.com",
    localUrl: "http://127.0.0.1:8230",
    apiToken: "",
    k: 10,
    authorBoost: 1,
    contextSentences: 6,
    citationPatterns: [
      "\\[@[^\\]]*\\]",
      "\\[cite\\]",
      "\\\\cite\\{[^}]*\\}"
    ],
    insertFormat: "({first_author}, {year})",
    autoDetectEnabled: false,
    debounceMs: 500,
    showParagraphs: true
  };

  // src/shared/constants.ts
  var DEFAULT_SETTINGS2 = {
    ...DEFAULT_SETTINGS,
    citationStyle: "apa",
    googleDocsCitationFormat: "({first_author}, {year})",
    overleafCitationFormat: "\\cite{{{bibtex_key}}}",
    showAbstracts: false
  };
  var STORAGE_KEY = "incite_settings";

  // src/shared/settings.ts
  async function loadSettings() {
    const result = await chrome.storage.sync.get(STORAGE_KEY);
    const stored = result[STORAGE_KEY] ?? {};
    const merged = { ...DEFAULT_SETTINGS2, ...stored };
    if (!stored.citationStyle && stored.googleDocsCitationFormat) {
      merged.citationStyle = DEFAULT_SETTINGS2.citationStyle;
      merged.googleDocsCitationFormat = DEFAULT_SETTINGS2.googleDocsCitationFormat;
    }
    return merged;
  }
  async function saveSettings(partial) {
    const current = await loadSettings();
    const updated = { ...current, ...partial };
    await chrome.storage.sync.set({ [STORAGE_KEY]: updated });
    return updated;
  }

  // src/options/options.ts
  var CITATION_PRESETS = {
    apa: "({first_author}, {year})",
    narrative: "{first_author} ({year})",
    mla: "({first_author})",
    harvard: "({first_author} {year})",
    bibtex: "[@{bibtex_key}]",
    latex: "\\cite{{{bibtex_key}}}"
  };
  var citationStyle = document.getElementById("citationStyle");
  var customFormatField = document.getElementById("custom-format-field");
  var customCitationFormat = document.getElementById("customCitationFormat");
  var apiToken = document.getElementById("apiToken");
  var kInput = document.getElementById("k");
  var showParagraphs = document.getElementById("showParagraphs");
  var showAbstracts = document.getElementById("showAbstracts");
  var apiModeRadios = document.querySelectorAll('input[name="apiMode"]');
  var localFields = document.getElementById("local-fields");
  var localUrl = document.getElementById("localUrl");
  var contextSentences = document.getElementById("contextSentences");
  var overleafFmt = document.getElementById("overleafCitationFormat");
  var btnTest = document.getElementById("btn-test");
  var testResult = document.getElementById("test-result");
  var btnSave = document.getElementById("btn-save");
  var saveStatus = document.getElementById("save-status");
  loadSettings().then(populateForm);
  citationStyle.addEventListener("change", () => {
    customFormatField.classList.toggle("hidden", citationStyle.value !== "custom");
  });
  apiModeRadios.forEach((radio) => {
    radio.addEventListener("change", () => {
      localFields.classList.toggle("hidden", radio.value !== "local");
    });
  });
  btnTest.addEventListener("click", async () => {
    testResult.textContent = "Testing...";
    testResult.className = "test-result";
    const selectedMode = document.querySelector('input[name="apiMode"]:checked');
    const currentSettings = {
      apiMode: selectedMode?.value ?? "cloud",
      cloudUrl: DEFAULT_SETTINGS2.cloudUrl,
      localUrl: localUrl.value.trim() || DEFAULT_SETTINGS2.localUrl,
      apiToken: apiToken.value.trim()
    };
    await saveSettings(currentSettings);
    try {
      const response = await chrome.runtime.sendMessage({ type: "CHECK_HEALTH" });
      if (response?.response) {
        testResult.textContent = `Connected -- ${response.response.corpus_size ?? "?"} papers (${response.response.mode ?? "unknown"} mode)`;
        testResult.className = "test-result success";
      } else {
        testResult.textContent = response?.error ?? "Connection failed";
        testResult.className = "test-result error";
      }
    } catch (err) {
      testResult.textContent = err instanceof Error ? err.message : "Connection failed";
      testResult.className = "test-result error";
    }
  });
  btnSave.addEventListener("click", async () => {
    const selectedMode = document.querySelector('input[name="apiMode"]:checked');
    let googleDocsFmtValue;
    if (citationStyle.value === "custom") {
      googleDocsFmtValue = customCitationFormat.value || DEFAULT_SETTINGS2.googleDocsCitationFormat;
    } else {
      googleDocsFmtValue = CITATION_PRESETS[citationStyle.value] || DEFAULT_SETTINGS2.googleDocsCitationFormat;
    }
    const settings = {
      apiMode: selectedMode?.value ?? "cloud",
      cloudUrl: DEFAULT_SETTINGS2.cloudUrl,
      localUrl: localUrl.value.trim() || DEFAULT_SETTINGS2.localUrl,
      apiToken: apiToken.value.trim(),
      k: parseInt(kInput.value) || DEFAULT_SETTINGS2.k,
      contextSentences: parseInt(contextSentences.value) || DEFAULT_SETTINGS2.contextSentences,
      citationStyle: citationStyle.value,
      googleDocsCitationFormat: googleDocsFmtValue,
      overleafCitationFormat: overleafFmt.value || DEFAULT_SETTINGS2.overleafCitationFormat,
      showParagraphs: showParagraphs.checked,
      showAbstracts: showAbstracts.checked
    };
    await saveSettings(settings);
    saveStatus.textContent = "Saved!";
    setTimeout(() => {
      saveStatus.textContent = "";
    }, 2e3);
  });
  function populateForm(settings) {
    citationStyle.value = settings.citationStyle || "apa";
    customFormatField.classList.toggle("hidden", citationStyle.value !== "custom");
    if (citationStyle.value === "custom") {
      customCitationFormat.value = settings.googleDocsCitationFormat;
    }
    apiToken.value = settings.apiToken;
    kInput.value = String(settings.k);
    showParagraphs.checked = settings.showParagraphs;
    showAbstracts.checked = settings.showAbstracts;
    apiModeRadios.forEach((radio) => {
      radio.checked = radio.value === settings.apiMode;
    });
    localFields.classList.toggle("hidden", settings.apiMode !== "local");
    localUrl.value = settings.localUrl;
    contextSentences.value = String(settings.contextSentences);
    overleafFmt.value = settings.overleafCitationFormat;
  }
})();
//# sourceMappingURL=options.js.map

"use strict";
(() => {
  // src/translators/generic.ts
  function extractFullText(doc) {
    const selectors = [
      // PMC / NCBI
      ".jig-ncbiinpagenav .tsec",
      // Elsevier / ScienceDirect
      "#body .section",
      // Nature / Springer
      "article .c-article-body",
      "article .article-body",
      "#article-body",
      // Wiley
      ".article-section__content",
      // PLOS
      ".article-content",
      // Generic semantic HTML
      '[role="main"] p',
      "article p",
      // Broadest fallback: main content paragraphs
      "main p"
    ];
    for (const selector of selectors) {
      const elements = doc.querySelectorAll(selector);
      if (elements.length === 0) continue;
      const paragraphs = [];
      for (const el of elements) {
        if (el.tagName !== "P") {
          const ps = el.querySelectorAll("p");
          for (const p of ps) {
            const text = p.textContent?.trim();
            if (text && text.length > 30) paragraphs.push(text);
          }
        } else {
          const text = el.textContent?.trim();
          if (text && text.length > 30) paragraphs.push(text);
        }
      }
      const fullText = paragraphs.join("\n\n");
      if (fullText.length >= 200) return fullText;
    }
    return null;
  }
  function getMeta(doc, names) {
    for (const name of names) {
      const el = doc.querySelector(`meta[name="${name}" i], meta[property="${name}" i]`);
      if (el) {
        const content = el.getAttribute("content");
        if (content?.trim()) return content.trim();
      }
    }
    return null;
  }
  function getAllMeta(doc, name) {
    const els = doc.querySelectorAll(`meta[name="${name}" i], meta[property="${name}" i]`);
    return Array.from(els).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
  }
  function parseYear(dateStr) {
    if (!dateStr) return void 0;
    const match = dateStr.match(/(\d{4})/);
    return match ? parseInt(match[1], 10) : void 0;
  }
  var genericTranslator = {
    name: "generic",
    urlPatterns: [],
    // Used as fallback, doesn't match by URL
    detect(doc) {
      const title = getMeta(doc, ["citation_title", "DC.Title", "DC.title"]);
      return title ? { type: "single" } : null;
    },
    extractSingle(doc) {
      const title = getMeta(doc, ["citation_title", "DC.Title", "DC.title", "og:title"]);
      if (!title) return null;
      const authors = getAllMeta(doc, "citation_author");
      if (!authors.length) {
        const dcAuthors = getAllMeta(doc, "DC.Creator");
        if (dcAuthors.length) authors.push(...dcAuthors);
      }
      const doi = getMeta(doc, ["citation_doi", "DC.Identifier"]) ?? void 0;
      const abstract = getMeta(doc, ["citation_abstract", "DC.Description", "og:description"]) ?? void 0;
      const journal = getMeta(doc, ["citation_journal_title", "DC.Source"]) ?? void 0;
      const year = parseYear(getMeta(doc, ["citation_date", "citation_publication_date", "DC.Date"]));
      const pdf_url = getMeta(doc, ["citation_pdf_url"]) ?? void 0;
      const full_text = extractFullText(doc) ?? void 0;
      return {
        title,
        authors: authors.length ? authors : void 0,
        year,
        doi,
        abstract,
        journal,
        url: doc.location.href,
        pdf_url,
        full_text
      };
    },
    extractMultiple(_doc) {
      return [];
    }
  };

  // src/translators/arxiv.ts
  function getMeta2(doc, name) {
    const el = doc.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return el?.getAttribute("content")?.trim() ?? null;
  }
  function getAllMeta2(doc, name) {
    return Array.from(doc.querySelectorAll(`meta[name="${name}"]`)).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
  }
  function extractArxivId(url) {
    const match = url.match(/arxiv\.org\/(?:abs|pdf|html)\/(\d{4}\.\d{4,5}(?:v\d+)?)/);
    return match ? match[1] : null;
  }
  var arxivTranslator = {
    name: "arxiv",
    urlPatterns: [/arxiv\.org\/(?:abs|pdf|html)\//],
    detect(doc) {
      const arxivId = extractArxivId(doc.location.href);
      const title = getMeta2(doc, "citation_title");
      return arxivId || title ? { type: "single" } : null;
    },
    extractSingle(doc) {
      const title = getMeta2(doc, "citation_title");
      if (!title) return null;
      const authors = getAllMeta2(doc, "citation_author");
      const doi = getMeta2(doc, "citation_doi") ?? void 0;
      const arxivId = extractArxivId(doc.location.href) ?? void 0;
      const dateStr = getMeta2(doc, "citation_date");
      const year = dateStr ? parseInt(dateStr.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0;
      const pdf_url = getMeta2(doc, "citation_pdf_url") ?? void 0;
      let abstract;
      const abstractBlock = doc.querySelector(".abstract");
      if (abstractBlock) {
        abstract = abstractBlock.textContent?.replace(/^Abstract:\s*/i, "").trim();
      }
      const isHtmlPage = doc.location.href.includes("/html/");
      const full_text = isHtmlPage ? extractFullText(doc) ?? void 0 : void 0;
      return {
        title,
        authors: authors.length ? authors : void 0,
        year,
        doi,
        abstract,
        journal: "arXiv",
        url: doc.location.href,
        arxiv_id: arxivId,
        pdf_url,
        full_text
      };
    },
    extractMultiple(_doc) {
      return [];
    }
  };

  // src/translators/semantic-scholar.ts
  function getMeta3(doc, name) {
    const el = doc.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return el?.getAttribute("content")?.trim() ?? null;
  }
  function findPdfUrl(doc) {
    const metaPdf = getMeta3(doc, "citation_pdf_url");
    if (metaPdf) return metaPdf;
    const pdfLink = doc.querySelector(
      'a[data-heap-id="paper-link-button"][href*=".pdf"], a[href*="arxiv.org/pdf"], a.cl-paper-view-paper[href*=".pdf"]'
    );
    if (pdfLink?.href) return pdfLink.href;
    return void 0;
  }
  var semanticScholarTranslator = {
    name: "semantic-scholar",
    urlPatterns: [/semanticscholar\.org\/paper\//, /semanticscholar\.org\/search/],
    detect(doc) {
      const url = doc.location.href;
      if (url.includes("/search")) {
        const results = doc.querySelectorAll("[data-test-id='search-result']");
        return results.length > 0 ? { type: "multiple" } : null;
      }
      const title = getMeta3(doc, "citation_title");
      return title ? { type: "single" } : null;
    },
    extractSingle(doc) {
      const jsonLd = doc.querySelector('script[type="application/ld+json"]');
      if (jsonLd) {
        try {
          const data = JSON.parse(jsonLd.textContent ?? "");
          if (data["@type"] === "ScholarlyArticle" && data.name) {
            const authors2 = Array.isArray(data.author) ? data.author.map((a) => a.name).filter(Boolean) : void 0;
            const doi = typeof data.sameAs === "string" && data.sameAs.includes("doi.org") ? data.sameAs.replace(/^https?:\/\/doi\.org\//, "") : void 0;
            return {
              title: data.name,
              authors: authors2,
              year: data.datePublished ? parseInt(data.datePublished.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0,
              doi,
              abstract: data.description ?? void 0,
              journal: data.isPartOf?.name ?? void 0,
              url: doc.location.href,
              pdf_url: findPdfUrl(doc)
            };
          }
        } catch {
        }
      }
      const title = getMeta3(doc, "citation_title");
      if (!title) return null;
      const authors = Array.from(doc.querySelectorAll('meta[name="citation_author"]')).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
      return {
        title,
        authors: authors.length ? authors : void 0,
        doi: getMeta3(doc, "citation_doi") ?? void 0,
        abstract: getMeta3(doc, "og:description") ?? void 0,
        url: doc.location.href,
        pdf_url: findPdfUrl(doc)
      };
    },
    extractMultiple(doc) {
      const results = [];
      const cards = doc.querySelectorAll("[data-test-id='search-result']");
      for (const card of cards) {
        try {
          const titleEl = card.querySelector("h2 a, [data-test-id='title'] a");
          const title = titleEl?.textContent?.trim();
          if (!title) continue;
          const authorEls = card.querySelectorAll("[data-test-id='author-list'] span a, .cl-paper-authors a");
          const authors = Array.from(authorEls).map((el) => el.textContent?.trim()).filter((a) => !!a);
          const yearEl = card.querySelector("[data-test-id='paper-year'] span, .cl-paper-year");
          const yearText = yearEl?.textContent?.trim();
          const year = yearText ? parseInt(yearText.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0;
          const href = titleEl?.getAttribute("href");
          const url = href?.startsWith("/") ? `https://www.semanticscholar.org${href}` : href ?? void 0;
          results.push({
            title,
            authors: authors.length ? authors : void 0,
            year,
            url
          });
        } catch {
        }
      }
      return results;
    }
  };

  // src/translators/google-scholar.ts
  var googleScholarTranslator = {
    name: "google-scholar",
    urlPatterns: [/scholar\.google\.\w+\/scholar/],
    detect(doc) {
      const results = doc.querySelectorAll(".gs_ri");
      return results.length > 0 ? { type: "multiple" } : null;
    },
    extractSingle(_doc) {
      return null;
    },
    extractMultiple(doc) {
      const results = [];
      const items = doc.querySelectorAll(".gs_ri");
      for (const item of items) {
        try {
          const titleEl = item.querySelector("h3 a");
          const title = titleEl?.textContent?.trim();
          if (!title) continue;
          const url = titleEl?.getAttribute("href") ?? void 0;
          const metaLine = item.querySelector(".gs_a")?.textContent ?? "";
          const parts = metaLine.split(" - ");
          let authors;
          let year;
          let journal;
          if (parts.length >= 1) {
            const authorStr = parts[0].trim();
            authors = authorStr.replace(/…$/, "").split(",").map((a) => a.trim()).filter((a) => a.length > 0 && !a.match(/^\d{4}$/));
            if (!authors.length) authors = void 0;
          }
          if (parts.length >= 2) {
            const yearMatch = parts[1].match(/(\d{4})/);
            year = yearMatch ? parseInt(yearMatch[1], 10) : void 0;
            const journalPart = parts[1].replace(/,?\s*\d{4}.*$/, "").trim();
            journal = journalPart || void 0;
          }
          const snippet = item.querySelector(".gs_rs")?.textContent?.trim() ?? void 0;
          const parentResult = item.closest(".gs_r");
          const pdfLink = parentResult?.querySelector(
            ".gs_ggs a, .gs_or_ggsm a"
          );
          const pdf_url = pdfLink?.href ?? void 0;
          results.push({
            title,
            authors,
            year,
            journal,
            url,
            abstract: snippet,
            // Scholar snippet is partial abstract at best
            pdf_url
          });
        } catch {
        }
      }
      return results;
    }
  };

  // src/translators/biorxiv.ts
  function getMeta4(doc, name) {
    const el = doc.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return el?.getAttribute("content")?.trim() ?? null;
  }
  function getAllMeta3(doc, name) {
    return Array.from(doc.querySelectorAll(`meta[name="${name}"]`)).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
  }
  var biorxivTranslator = {
    name: "biorxiv",
    urlPatterns: [/biorxiv\.org\/content\//, /medrxiv\.org\/content\//],
    detect(doc) {
      const title = getMeta4(doc, "citation_title");
      return title ? { type: "single" } : null;
    },
    extractSingle(doc) {
      const title = getMeta4(doc, "citation_title");
      if (!title) return null;
      const authors = getAllMeta3(doc, "citation_author");
      const doi = getMeta4(doc, "citation_doi") ?? void 0;
      const journal = getMeta4(doc, "citation_journal_title") ?? void 0;
      const dateStr = getMeta4(doc, "citation_date") ?? getMeta4(doc, "citation_publication_date");
      const year = dateStr ? parseInt(dateStr.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0;
      const pdf_url = getMeta4(doc, "citation_pdf_url") ?? void 0;
      let abstract;
      const abstractDiv = doc.querySelector(".abstract, #abstract");
      if (abstractDiv) {
        abstract = abstractDiv.textContent?.replace(/^Abstract\s*/i, "").trim();
      }
      const full_text = extractFullText(doc) ?? void 0;
      return {
        title,
        authors: authors.length ? authors : void 0,
        year,
        doi,
        abstract,
        journal,
        url: doc.location.href,
        pdf_url,
        full_text
      };
    },
    extractMultiple(_doc) {
      return [];
    }
  };

  // src/translators/pubmed.ts
  function getMeta5(doc, name) {
    const el = doc.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return el?.getAttribute("content")?.trim() ?? null;
  }
  function getAllMeta4(doc, name) {
    return Array.from(doc.querySelectorAll(`meta[name="${name}"]`)).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
  }
  var pubmedTranslator = {
    name: "pubmed",
    urlPatterns: [/pubmed\.ncbi\.nlm\.nih\.gov\/\d/],
    detect(doc) {
      const title = getMeta5(doc, "citation_title");
      return title ? { type: "single" } : null;
    },
    extractSingle(doc) {
      const title = getMeta5(doc, "citation_title");
      if (!title) return null;
      const authors = getAllMeta4(doc, "citation_author");
      const doi = getMeta5(doc, "citation_doi") ?? void 0;
      const journal = getMeta5(doc, "citation_journal_title") ?? void 0;
      const dateStr = getMeta5(doc, "citation_date") ?? getMeta5(doc, "citation_publication_date");
      const year = dateStr ? parseInt(dateStr.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0;
      const pdf_url = getMeta5(doc, "citation_pdf_url") ?? void 0;
      let abstract;
      const abstractDiv = doc.querySelector("#abstract, .abstract-content");
      if (abstractDiv) {
        abstract = abstractDiv.textContent?.trim();
      }
      const full_text = extractFullText(doc) ?? void 0;
      return {
        title,
        authors: authors.length ? authors : void 0,
        year,
        doi,
        abstract,
        journal,
        url: doc.location.href,
        pdf_url,
        full_text
      };
    },
    extractMultiple(_doc) {
      return [];
    }
  };

  // src/translators/registry.ts
  var TRANSLATORS = [
    arxivTranslator,
    semanticScholarTranslator,
    googleScholarTranslator,
    biorxivTranslator,
    pubmedTranslator
    // generic is the fallback, not in this array
  ];
  function findTranslator(url) {
    for (const t of TRANSLATORS) {
      if (t.urlPatterns.some((p) => p.test(url))) {
        return t;
      }
    }
    return genericTranslator;
  }

  // src/content/translator-runner.ts
  (function() {
    const translator = findTranslator(location.href);
    const detection = translator.detect(document);
    if (detection) {
      let papers;
      if (detection.type === "single") {
        const paper = translator.extractSingle(document);
        papers = paper ? [paper] : void 0;
      } else {
        papers = translator.extractMultiple(document);
      }
      chrome.runtime.sendMessage({
        type: "PAGE_PAPERS_DETECTED",
        detection,
        papers,
        translatorName: translator.name
      });
    }
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message.type === "EXTRACT_PAPERS") {
        const t = findTranslator(location.href);
        const d = t.detect(document);
        if (!d) {
          sendResponse({ papers: [], type: null });
          return;
        }
        let extracted;
        if (d.type === "single") {
          const paper = t.extractSingle(document);
          extracted = paper ? [paper] : [];
        } else {
          extracted = t.extractMultiple(document);
        }
        sendResponse({ papers: extracted, type: d.type });
      }
      return true;
    });
  })();
})();
//# sourceMappingURL=translator-runner.js.map

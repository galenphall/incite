"use strict";
(() => {
  // src/content/shared.ts
  function showToast(message, duration = 3e3) {
    const existing = document.getElementById("incite-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "incite-toast";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      padding: "10px 18px",
      background: "#1a1a2e",
      color: "#fff",
      borderRadius: "8px",
      fontSize: "13px",
      zIndex: "999999",
      boxShadow: "0 4px 12px rgba(0,0,0,0.15)"
    });
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), duration);
  }

  // src/content/googledocs.ts
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    switch (message.type) {
      case "GET_CONTEXT": {
        extractText().then((result) => {
          sendResponse({ type: "CONTEXT_RESPONSE", requestId: message.requestId, ...result });
        });
        return true;
      }
      case "INSERT_CITATION": {
        navigator.clipboard.writeText(message.citation).then(() => {
          showToast(`Copied "${message.citation}" -- paste with Cmd/Ctrl+V`);
          sendResponse({ type: "INSERT_RESULT", success: true, method: "clipboard" });
        }).catch((err) => {
          console.error("Failed to copy citation to clipboard:", err);
          sendResponse({ type: "INSERT_RESULT", success: false, error: err?.message });
        });
        return true;
      }
    }
  });
  async function extractText() {
    const selection = window.getSelection();
    const selectedText = selection?.toString().trim();
    if (selectedText && selectedText.length > 0) {
      return { text: selectedText };
    }
    try {
      const clipboardText = await extractViaClipboard();
      if (clipboardText && clipboardText.length > 0) {
        return { text: clipboardText };
      }
    } catch (err) {
      console.debug("Clipboard extraction failed:", err);
    }
    return {
      error: "Could not extract text. Select text in your document and try again, or use the manual text input in the panel below."
    };
  }
  async function extractViaClipboard() {
    let savedClipboard = null;
    try {
      savedClipboard = await navigator.clipboard.readText();
    } catch (err) {
      console.debug("Could not read clipboard to save:", err);
    }
    document.execCommand("copy");
    await new Promise((resolve) => setTimeout(resolve, 100));
    const copiedText = await navigator.clipboard.readText();
    if (savedClipboard !== null && savedClipboard !== copiedText) {
      try {
        await navigator.clipboard.writeText(savedClipboard);
      } catch (err) {
        console.debug("Clipboard restore failed:", err);
      }
    }
    return copiedText?.trim() ?? "";
  }
})();
//# sourceMappingURL=googledocs.js.map

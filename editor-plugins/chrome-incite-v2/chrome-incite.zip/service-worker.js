"use strict";
(() => {
  // ../shared/src/types.ts
  var DEFAULT_SETTINGS = {
    apiMode: "cloud",
    cloudUrl: "https://inciteref.com",
    localUrl: "http://127.0.0.1:8230",
    apiToken: "",
    k: 10,
    authorBoost: 1,
    contextSentences: 6,
    citationPatterns: [
      "\\[@[^\\]]*\\]",
      "\\[cite\\]",
      "\\\\cite\\{[^}]*\\}"
    ],
    insertFormat: "({first_author}, {year})",
    autoDetectEnabled: false,
    debounceMs: 500,
    showParagraphs: true
  };
  function getActiveUrl(settings) {
    return settings.apiMode === "cloud" ? settings.cloudUrl : settings.localUrl;
  }

  // ../shared/src/api-client.ts
  var FetchTransport = class {
    async get(url, headers) {
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Accept": "application/json",
          ...headers
        }
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return response.json();
    }
    async post(url, body, headers) {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          ...headers
        },
        body: JSON.stringify(body)
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return response.json();
    }
  };
  var InCiteClient = class {
    /**
     * Create an InCiteClient.
     *
     * Accepts either a `ClientConfig` object (cloud-aware) or a plain `baseUrl`
     * string for backward compatibility.
     */
    constructor(configOrBaseUrl, transport) {
      if (typeof configOrBaseUrl === "string") {
        this.config = {
          apiMode: "local",
          cloudUrl: "https://inciteref.com",
          localUrl: configOrBaseUrl,
          apiToken: ""
        };
      } else {
        this.config = { ...configOrBaseUrl };
      }
      this.transport = transport ?? new FetchTransport();
    }
    /** Update client configuration (partial merge). */
    updateConfig(partial) {
      Object.assign(this.config, partial);
    }
    /** @deprecated Use updateConfig() instead. */
    setBaseUrl(url) {
      this.config.localUrl = url;
    }
    /** Get the currently active base URL. */
    getBaseUrl() {
      return this.config.apiMode === "cloud" ? this.config.cloudUrl : this.config.localUrl;
    }
    /** Get auth headers for the current mode. */
    getAuthHeaders() {
      if (this.config.apiMode === "cloud" && this.config.apiToken) {
        return { "Authorization": `Bearer ${this.config.apiToken}` };
      }
      return {};
    }
    /** Get the endpoint path, adjusting for cloud vs local. */
    getEndpoint(localPath) {
      if (this.config.apiMode === "cloud") {
        switch (localPath) {
          case "/health":
            return "/api/v1/health";
          case "/recommend":
            return "/api/v1/recommend";
          default:
            return localPath;
        }
      }
      return localPath;
    }
    /** Make an authenticated GET request. */
    async authGet(path) {
      const url = `${this.getBaseUrl()}${this.getEndpoint(path)}`;
      return this.transport.get(url, this.getAuthHeaders());
    }
    /** Make an authenticated POST request. */
    async authPost(path, body) {
      const url = `${this.getBaseUrl()}${this.getEndpoint(path)}`;
      return this.transport.post(url, body, this.getAuthHeaders());
    }
    /** Check if the server is healthy and ready. */
    async health() {
      const resp = await this.authGet("/health");
      const data = resp;
      if (this.config.apiMode === "cloud" && data.ready === void 0) {
        return {
          ...data,
          ready: data.status === "ready"
        };
      }
      return data;
    }
    /** Get citation recommendations for a query. */
    async recommend(query, k, authorBoost, cursorSentenceIndex) {
      const body = {
        query,
        k,
        author_boost: authorBoost
      };
      if (cursorSentenceIndex !== void 0) {
        body.cursor_sentence_index = cursorSentenceIndex;
      }
      const resp = await this.authPost("/recommend", body);
      return resp;
    }
    /** Save papers to the user's library. */
    async savePapers(request) {
      const resp = await this.authPost("/api/v1/library/papers", request);
      return resp;
    }
    /** Check which papers are already in the user's library. */
    async checkLibrary(papers) {
      const resp = await this.authPost("/api/v1/library/check", { papers });
      return resp.results;
    }
    /** List the user's collections. */
    async getCollections() {
      const resp = await this.authGet("/api/v1/library/collections");
      return resp.collections;
    }
    /** Search tags by prefix. */
    async searchTags(query) {
      const q = encodeURIComponent(query);
      const resp = await this.authGet(`/api/v1/library/tags/search?q=${q}`);
      return resp.tags;
    }
  };

  // ../shared/src/context-extractor.ts
  function splitSentences(text) {
    const abbrevs = /(?:Dr|Mr|Mrs|Ms|Prof|Sr|Jr|etc|Fig|Figs|Eq|Eqs|al|vs|i\.e|e\.g|cf|no|vol|pp|ed|Rev|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.\s*/gi;
    const placeholder = "\0";
    let processed = text.replace(
      abbrevs,
      (match) => match.replace(/\.\s*/, placeholder)
    );
    const parts = processed.split(/(?<=[.!?])\s+(?=[A-Z"])/);
    return parts.map((s) => s.replace(new RegExp(placeholder, "g"), ". ").trim()).filter((s) => s.length > 0);
  }
  function stripCitations(text) {
    return text.replace(/\[@[^\]]*\]/g, "").replace(/\[cite\]/gi, "").replace(/\\cite\{[^}]*\}/g, "").replace(/\s{2,}/g, " ").trim();
  }
  function extractContext(fullText, cursorOffset, windowSentences) {
    const lines = fullText.split("\n");
    let charCount = 0;
    let cursorLine = 0;
    for (let i = 0; i < lines.length; i++) {
      charCount += lines[i].length + 1;
      if (charCount > cursorOffset) {
        cursorLine = i;
        break;
      }
    }
    const windowLines = 50;
    const startLine = Math.max(0, cursorLine - windowLines);
    const endLine = Math.min(lines.length, cursorLine + windowLines);
    const windowText = lines.slice(startLine, endLine).join("\n");
    let windowStartOffset = 0;
    for (let i = 0; i < startLine; i++) {
      windowStartOffset += lines[i].length + 1;
    }
    const windowCursorOffset = cursorOffset - windowStartOffset;
    const sentences = splitSentences(windowText);
    if (sentences.length === 0) {
      return {
        text: stripCitations(windowText),
        rawText: windowText,
        cursorSentenceIndex: 0,
        totalSentences: 0
      };
    }
    let accum = 0;
    let cursorSentence = 0;
    for (let i = 0; i < sentences.length; i++) {
      const idx = windowText.indexOf(sentences[i], accum);
      if (idx === -1) continue;
      const sentEnd = idx + sentences[i].length;
      if (windowCursorOffset >= idx && windowCursorOffset <= sentEnd) {
        cursorSentence = i;
        break;
      }
      if (idx > windowCursorOffset) {
        cursorSentence = Math.max(0, i - 1);
        break;
      }
      accum = sentEnd;
      cursorSentence = i;
    }
    const halfWindow = Math.floor(windowSentences / 2);
    const start = Math.max(0, cursorSentence - halfWindow);
    const end = Math.min(sentences.length, cursorSentence + halfWindow + 1);
    const selectedSentences = sentences.slice(start, end);
    const rawText = selectedSentences.join(" ");
    return {
      text: stripCitations(rawText),
      rawText,
      cursorSentenceIndex: cursorSentence - start,
      totalSentences: selectedSentences.length
    };
  }

  // ../shared/src/format.ts
  function formatCitation(rec, template) {
    const firstAuthor = rec.authors?.[0] ? rec.authors[0].split(",")[0].split(" ").pop() ?? "" : "";
    const fallbackKey = firstAuthor && rec.year ? `${firstAuthor}${rec.year}` : firstAuthor || rec.title?.split(/\s+/).slice(0, 3).join("") || rec.paper_id;
    const values = {
      bibtex_key: rec.bibtex_key ?? fallbackKey,
      paper_id: rec.paper_id,
      first_author: firstAuthor,
      year: rec.year?.toString() ?? "",
      title: rec.title,
      zotero_uri: rec.zotero_uri ?? ""
    };
    let result = template;
    for (const [key, value] of Object.entries(values)) {
      result = result.replace(new RegExp(`\\{${key}\\}`, "g"), value);
      result = result.replace(new RegExp(`\\$\\{${key}\\}`, "g"), value);
    }
    return result;
  }
  function detectCitationStyle(template) {
    if (/\\cite\{/.test(template)) return "latex";
    if (/\[@/.test(template)) return "pandoc";
    return "individual";
  }
  function formatMultiCitation(recs, template, separator = "; ") {
    if (recs.length === 0) return "";
    if (recs.length === 1) return formatCitation(recs[0], template);
    const style = detectCitationStyle(template);
    switch (style) {
      case "latex": {
        const keys = recs.map((r) => r.bibtex_key ?? r.paper_id);
        return `\\cite{${keys.join(",")}}`;
      }
      case "pandoc": {
        const keys = recs.map((r) => r.bibtex_key ?? r.paper_id);
        return `[@${keys.join("; @")}]`;
      }
      case "individual": {
        const formatted = recs.map((r) => formatCitation(r, template));
        const first = formatted[0];
        const delimPairs = [["(", ")"], ["[", "]"]];
        const match = delimPairs.find(
          ([open, close]) => first.startsWith(open) && first.endsWith(close)
        );
        if (match) {
          const [open, close] = match;
          const inner = formatted.map((s) => s.slice(1, -1));
          return `${open}${inner.join(separator)}${close}`;
        }
        return formatted.join(separator);
      }
    }
  }

  // src/shared/constants.ts
  var DEFAULT_SETTINGS2 = {
    ...DEFAULT_SETTINGS,
    citationStyle: "apa",
    googleDocsCitationFormat: "({first_author}, {year})",
    overleafCitationFormat: "\\cite{{{bibtex_key}}}",
    showAbstracts: false
  };
  var STORAGE_KEY = "incite_settings";

  // src/shared/settings.ts
  async function loadSettings() {
    const result = await chrome.storage.sync.get(STORAGE_KEY);
    const stored = result[STORAGE_KEY] ?? {};
    const merged = { ...DEFAULT_SETTINGS2, ...stored };
    if (!stored.citationStyle && stored.googleDocsCitationFormat) {
      merged.citationStyle = DEFAULT_SETTINGS2.citationStyle;
      merged.googleDocsCitationFormat = DEFAULT_SETTINGS2.googleDocsCitationFormat;
    }
    return merged;
  }
  async function saveSettings(partial) {
    const current = await loadSettings();
    const updated = { ...current, ...partial };
    await chrome.storage.sync.set({ [STORAGE_KEY]: updated });
    return updated;
  }

  // src/translators/generic.ts
  function extractFullText(doc) {
    const selectors = [
      // PMC / NCBI
      ".jig-ncbiinpagenav .tsec",
      // Elsevier / ScienceDirect
      "#body .section",
      // Nature / Springer
      "article .c-article-body",
      "article .article-body",
      "#article-body",
      // Wiley
      ".article-section__content",
      // PLOS
      ".article-content",
      // Generic semantic HTML
      '[role="main"] p',
      "article p",
      // Broadest fallback: main content paragraphs
      "main p"
    ];
    for (const selector of selectors) {
      const elements = doc.querySelectorAll(selector);
      if (elements.length === 0) continue;
      const paragraphs = [];
      for (const el of elements) {
        if (el.tagName !== "P") {
          const ps = el.querySelectorAll("p");
          for (const p of ps) {
            const text = p.textContent?.trim();
            if (text && text.length > 30) paragraphs.push(text);
          }
        } else {
          const text = el.textContent?.trim();
          if (text && text.length > 30) paragraphs.push(text);
        }
      }
      const fullText = paragraphs.join("\n\n");
      if (fullText.length >= 200) return fullText;
    }
    return null;
  }

  // src/translators/arxiv.ts
  function getMeta(doc, name) {
    const el = doc.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return el?.getAttribute("content")?.trim() ?? null;
  }
  function getAllMeta(doc, name) {
    return Array.from(doc.querySelectorAll(`meta[name="${name}"]`)).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
  }
  function extractArxivId(url) {
    const match = url.match(/arxiv\.org\/(?:abs|pdf|html)\/(\d{4}\.\d{4,5}(?:v\d+)?)/);
    return match ? match[1] : null;
  }
  var arxivTranslator = {
    name: "arxiv",
    urlPatterns: [/arxiv\.org\/(?:abs|pdf|html)\//],
    detect(doc) {
      const arxivId = extractArxivId(doc.location.href);
      const title = getMeta(doc, "citation_title");
      return arxivId || title ? { type: "single" } : null;
    },
    extractSingle(doc) {
      const title = getMeta(doc, "citation_title");
      if (!title) return null;
      const authors = getAllMeta(doc, "citation_author");
      const doi = getMeta(doc, "citation_doi") ?? void 0;
      const arxivId = extractArxivId(doc.location.href) ?? void 0;
      const dateStr = getMeta(doc, "citation_date");
      const year = dateStr ? parseInt(dateStr.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0;
      const pdf_url = getMeta(doc, "citation_pdf_url") ?? void 0;
      let abstract;
      const abstractBlock = doc.querySelector(".abstract");
      if (abstractBlock) {
        abstract = abstractBlock.textContent?.replace(/^Abstract:\s*/i, "").trim();
      }
      const isHtmlPage = doc.location.href.includes("/html/");
      const full_text = isHtmlPage ? extractFullText(doc) ?? void 0 : void 0;
      return {
        title,
        authors: authors.length ? authors : void 0,
        year,
        doi,
        abstract,
        journal: "arXiv",
        url: doc.location.href,
        arxiv_id: arxivId,
        pdf_url,
        full_text
      };
    },
    extractMultiple(_doc) {
      return [];
    }
  };

  // src/translators/semantic-scholar.ts
  function getMeta2(doc, name) {
    const el = doc.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return el?.getAttribute("content")?.trim() ?? null;
  }
  function findPdfUrl(doc) {
    const metaPdf = getMeta2(doc, "citation_pdf_url");
    if (metaPdf) return metaPdf;
    const pdfLink = doc.querySelector(
      'a[data-heap-id="paper-link-button"][href*=".pdf"], a[href*="arxiv.org/pdf"], a.cl-paper-view-paper[href*=".pdf"]'
    );
    if (pdfLink?.href) return pdfLink.href;
    return void 0;
  }
  var semanticScholarTranslator = {
    name: "semantic-scholar",
    urlPatterns: [/semanticscholar\.org\/paper\//, /semanticscholar\.org\/search/],
    detect(doc) {
      const url = doc.location.href;
      if (url.includes("/search")) {
        const results = doc.querySelectorAll("[data-test-id='search-result']");
        return results.length > 0 ? { type: "multiple" } : null;
      }
      const title = getMeta2(doc, "citation_title");
      return title ? { type: "single" } : null;
    },
    extractSingle(doc) {
      const jsonLd = doc.querySelector('script[type="application/ld+json"]');
      if (jsonLd) {
        try {
          const data = JSON.parse(jsonLd.textContent ?? "");
          if (data["@type"] === "ScholarlyArticle" && data.name) {
            const authors2 = Array.isArray(data.author) ? data.author.map((a) => a.name).filter(Boolean) : void 0;
            const doi = typeof data.sameAs === "string" && data.sameAs.includes("doi.org") ? data.sameAs.replace(/^https?:\/\/doi\.org\//, "") : void 0;
            return {
              title: data.name,
              authors: authors2,
              year: data.datePublished ? parseInt(data.datePublished.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0,
              doi,
              abstract: data.description ?? void 0,
              journal: data.isPartOf?.name ?? void 0,
              url: doc.location.href,
              pdf_url: findPdfUrl(doc)
            };
          }
        } catch {
        }
      }
      const title = getMeta2(doc, "citation_title");
      if (!title) return null;
      const authors = Array.from(doc.querySelectorAll('meta[name="citation_author"]')).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
      return {
        title,
        authors: authors.length ? authors : void 0,
        doi: getMeta2(doc, "citation_doi") ?? void 0,
        abstract: getMeta2(doc, "og:description") ?? void 0,
        url: doc.location.href,
        pdf_url: findPdfUrl(doc)
      };
    },
    extractMultiple(doc) {
      const results = [];
      const cards = doc.querySelectorAll("[data-test-id='search-result']");
      for (const card of cards) {
        try {
          const titleEl = card.querySelector("h2 a, [data-test-id='title'] a");
          const title = titleEl?.textContent?.trim();
          if (!title) continue;
          const authorEls = card.querySelectorAll("[data-test-id='author-list'] span a, .cl-paper-authors a");
          const authors = Array.from(authorEls).map((el) => el.textContent?.trim()).filter((a) => !!a);
          const yearEl = card.querySelector("[data-test-id='paper-year'] span, .cl-paper-year");
          const yearText = yearEl?.textContent?.trim();
          const year = yearText ? parseInt(yearText.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0;
          const href = titleEl?.getAttribute("href");
          const url = href?.startsWith("/") ? `https://www.semanticscholar.org${href}` : href ?? void 0;
          results.push({
            title,
            authors: authors.length ? authors : void 0,
            year,
            url
          });
        } catch {
        }
      }
      return results;
    }
  };

  // src/translators/google-scholar.ts
  var googleScholarTranslator = {
    name: "google-scholar",
    urlPatterns: [/scholar\.google\.\w+\/scholar/],
    detect(doc) {
      const results = doc.querySelectorAll(".gs_ri");
      return results.length > 0 ? { type: "multiple" } : null;
    },
    extractSingle(_doc) {
      return null;
    },
    extractMultiple(doc) {
      const results = [];
      const items = doc.querySelectorAll(".gs_ri");
      for (const item of items) {
        try {
          const titleEl = item.querySelector("h3 a");
          const title = titleEl?.textContent?.trim();
          if (!title) continue;
          const url = titleEl?.getAttribute("href") ?? void 0;
          const metaLine = item.querySelector(".gs_a")?.textContent ?? "";
          const parts = metaLine.split(" - ");
          let authors;
          let year;
          let journal;
          if (parts.length >= 1) {
            const authorStr = parts[0].trim();
            authors = authorStr.replace(/…$/, "").split(",").map((a) => a.trim()).filter((a) => a.length > 0 && !a.match(/^\d{4}$/));
            if (!authors.length) authors = void 0;
          }
          if (parts.length >= 2) {
            const yearMatch = parts[1].match(/(\d{4})/);
            year = yearMatch ? parseInt(yearMatch[1], 10) : void 0;
            const journalPart = parts[1].replace(/,?\s*\d{4}.*$/, "").trim();
            journal = journalPart || void 0;
          }
          const snippet = item.querySelector(".gs_rs")?.textContent?.trim() ?? void 0;
          const parentResult = item.closest(".gs_r");
          const pdfLink = parentResult?.querySelector(
            ".gs_ggs a, .gs_or_ggsm a"
          );
          const pdf_url = pdfLink?.href ?? void 0;
          results.push({
            title,
            authors,
            year,
            journal,
            url,
            abstract: snippet,
            // Scholar snippet is partial abstract at best
            pdf_url
          });
        } catch {
        }
      }
      return results;
    }
  };

  // src/translators/biorxiv.ts
  function getMeta3(doc, name) {
    const el = doc.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return el?.getAttribute("content")?.trim() ?? null;
  }
  function getAllMeta2(doc, name) {
    return Array.from(doc.querySelectorAll(`meta[name="${name}"]`)).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
  }
  var biorxivTranslator = {
    name: "biorxiv",
    urlPatterns: [/biorxiv\.org\/content\//, /medrxiv\.org\/content\//],
    detect(doc) {
      const title = getMeta3(doc, "citation_title");
      return title ? { type: "single" } : null;
    },
    extractSingle(doc) {
      const title = getMeta3(doc, "citation_title");
      if (!title) return null;
      const authors = getAllMeta2(doc, "citation_author");
      const doi = getMeta3(doc, "citation_doi") ?? void 0;
      const journal = getMeta3(doc, "citation_journal_title") ?? void 0;
      const dateStr = getMeta3(doc, "citation_date") ?? getMeta3(doc, "citation_publication_date");
      const year = dateStr ? parseInt(dateStr.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0;
      const pdf_url = getMeta3(doc, "citation_pdf_url") ?? void 0;
      let abstract;
      const abstractDiv = doc.querySelector(".abstract, #abstract");
      if (abstractDiv) {
        abstract = abstractDiv.textContent?.replace(/^Abstract\s*/i, "").trim();
      }
      const full_text = extractFullText(doc) ?? void 0;
      return {
        title,
        authors: authors.length ? authors : void 0,
        year,
        doi,
        abstract,
        journal,
        url: doc.location.href,
        pdf_url,
        full_text
      };
    },
    extractMultiple(_doc) {
      return [];
    }
  };

  // src/translators/pubmed.ts
  function getMeta4(doc, name) {
    const el = doc.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return el?.getAttribute("content")?.trim() ?? null;
  }
  function getAllMeta3(doc, name) {
    return Array.from(doc.querySelectorAll(`meta[name="${name}"]`)).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
  }
  var pubmedTranslator = {
    name: "pubmed",
    urlPatterns: [/pubmed\.ncbi\.nlm\.nih\.gov\/\d/],
    detect(doc) {
      const title = getMeta4(doc, "citation_title");
      return title ? { type: "single" } : null;
    },
    extractSingle(doc) {
      const title = getMeta4(doc, "citation_title");
      if (!title) return null;
      const authors = getAllMeta3(doc, "citation_author");
      const doi = getMeta4(doc, "citation_doi") ?? void 0;
      const journal = getMeta4(doc, "citation_journal_title") ?? void 0;
      const dateStr = getMeta4(doc, "citation_date") ?? getMeta4(doc, "citation_publication_date");
      const year = dateStr ? parseInt(dateStr.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0;
      const pdf_url = getMeta4(doc, "citation_pdf_url") ?? void 0;
      let abstract;
      const abstractDiv = doc.querySelector("#abstract, .abstract-content");
      if (abstractDiv) {
        abstract = abstractDiv.textContent?.trim();
      }
      const full_text = extractFullText(doc) ?? void 0;
      return {
        title,
        authors: authors.length ? authors : void 0,
        year,
        doi,
        abstract,
        journal,
        url: doc.location.href,
        pdf_url,
        full_text
      };
    },
    extractMultiple(_doc) {
      return [];
    }
  };

  // src/translators/registry.ts
  var TRANSLATORS = [
    arxivTranslator,
    semanticScholarTranslator,
    googleScholarTranslator,
    biorxivTranslator,
    pubmedTranslator
    // generic is the fallback, not in this array
  ];
  function isAcademicSite(url) {
    for (const t of TRANSLATORS) {
      if (t.urlPatterns.some((p) => p.test(url))) return true;
    }
    if (/doi\.org\//.test(url)) return true;
    return false;
  }

  // src/background/service-worker.ts
  var detectedPapers = /* @__PURE__ */ new Map();
  var client = null;
  function configFromSettings(settings) {
    return {
      apiMode: settings.apiMode,
      cloudUrl: settings.cloudUrl,
      localUrl: settings.localUrl,
      apiToken: settings.apiToken
    };
  }
  async function getClient() {
    const settings = await loadSettings();
    if (!client) {
      client = new InCiteClient(configFromSettings(settings), new FetchTransport());
    } else {
      client.updateConfig(configFromSettings(settings));
    }
    return client;
  }
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
  var panelReady = false;
  chrome.action.onClicked.addListener(async (tab) => {
    if (tab.id) {
      await chrome.sidePanel.open({ tabId: tab.id });
    }
  });
  chrome.commands.onCommand.addListener(async (command) => {
    if (command === "trigger-recommendations") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) {
        await chrome.sidePanel.open({ tabId: tab.id });
        await sendHotkeyTriggerWithRetry();
      }
    }
    if (command === "save-to-library") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) return;
      const cached = detectedPapers.get(tab.id);
      let papers = [];
      if (cached && cached.type === "single") {
        papers = cached.papers;
      } else if (!cached) {
        const result = await handleGetDetectedPapers();
        if (result.type === "single") {
          papers = result.papers ?? [];
        }
      }
      if (papers.length > 0) {
        await quickSavePapers(papers);
      } else {
        await chrome.action.setBadgeText({ tabId: tab.id, text: "!" });
        await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: "#E74C3C" });
        setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: "" }), 2e3);
      }
    }
  });
  async function sendHotkeyTriggerWithRetry(maxAttempts = 3, intervalMs = 200) {
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      try {
        const response = await chrome.runtime.sendMessage({ type: "TRIGGER_FROM_HOTKEY" });
        if (response?.ack) return;
      } catch {
      }
      await new Promise((resolve) => setTimeout(resolve, intervalMs));
    }
    console.error("sendHotkeyTriggerWithRetry: all attempts failed \u2014 panel not responding");
  }
  chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (!tab.url) return;
    const isWriting = tab.url.includes("docs.google.com/document") || tab.url.includes("overleaf.com/project");
    const isAcademic = isAcademicSite(tab.url);
    if (isWriting) {
      await chrome.sidePanel.setOptions({ tabId, enabled: true });
      await chrome.action.setPopup({ tabId, popup: "" });
    } else if (isAcademic) {
      await chrome.sidePanel.setOptions({ tabId, enabled: false });
      await chrome.action.setPopup({ tabId, popup: "popup/popup.html" });
    } else {
      await chrome.sidePanel.setOptions({ tabId, enabled: false });
      await chrome.action.setPopup({ tabId, popup: "popup/popup.html" });
    }
    if (changeInfo.url) {
      detectedPapers.delete(tabId);
      await chrome.action.setBadgeText({ tabId, text: "" });
    }
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    detectedPapers.delete(tabId);
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "PANEL_READY") {
      panelReady = true;
      sendResponse({ ack: true });
      return false;
    }
    if (message.type === "PAGE_PAPERS_DETECTED") {
      const tabId = sender.tab?.id;
      if (tabId !== void 0) {
        const msg = message;
        detectedPapers.set(tabId, {
          type: msg.detection.type,
          papers: msg.papers ?? [],
          translatorName: msg.translatorName
        });
        updateBadge(tabId, msg.detection.type, msg.papers ?? []);
      }
      sendResponse({ ack: true });
      return false;
    }
    handleMessage(message, sender).then(sendResponse).catch((err) => {
      sendResponse({ error: err instanceof Error ? err.message : String(err) });
    });
    return true;
  });
  async function updateBadge(tabId, type, papers) {
    const settings = await loadSettings();
    if (settings.apiToken && type === "single" && papers.length === 1) {
      try {
        const apiClient = await getClient();
        const checkPapers = papers.map((p) => ({ doi: p.doi ?? null, title: p.title }));
        const results = await apiClient.checkLibrary(checkPapers);
        if (results?.[0]?.in_library) {
          await chrome.action.setBadgeText({ tabId, text: "\u2713" });
          await chrome.action.setBadgeBackgroundColor({ tabId, color: "#2ECC71" });
          return;
        }
      } catch {
      }
    }
    if (type === "single") {
      await chrome.action.setBadgeText({ tabId, text: "1" });
      await chrome.action.setBadgeBackgroundColor({ tabId, color: "#4A90D9" });
    } else {
      await chrome.action.setBadgeText({ tabId, text: "+" });
      await chrome.action.setBadgeBackgroundColor({ tabId, color: "#4A90D9" });
    }
  }
  async function quickSavePapers(papers) {
    const settings = await loadSettings();
    if (!settings.apiToken) return false;
    const tab = await getActiveTab();
    const tabId = tab?.id;
    try {
      const apiClient = await getClient();
      const stored = await chrome.storage.local.get("lastCollectionId");
      const collectionId = stored.lastCollectionId ?? null;
      await apiClient.savePapers({
        papers,
        collection_id: collectionId,
        tags: [],
        enrich: true
      });
      if (tabId) {
        await chrome.action.setBadgeText({ tabId, text: "\u2713" });
        await chrome.action.setBadgeBackgroundColor({ tabId, color: "#2ECC71" });
      }
      return true;
    } catch {
      if (tabId) {
        await chrome.action.setBadgeText({ tabId, text: "!" });
        await chrome.action.setBadgeBackgroundColor({ tabId, color: "#E74C3C" });
        setTimeout(() => chrome.action.setBadgeText({ tabId, text: "" }), 2e3);
      }
      return false;
    }
  }
  async function resolveMetadataFromUrl(url) {
    let s2Url = null;
    const doiMatch = url.match(/doi\.org\/(.+)/);
    if (doiMatch) {
      const doi = decodeURIComponent(doiMatch[1]).replace(/\/$/, "");
      s2Url = `https://api.semanticscholar.org/graph/v1/paper/DOI:${encodeURIComponent(doi)}?fields=title,abstract,authors,year,venue,externalIds`;
    }
    if (!s2Url) {
      const arxivMatch = url.match(/arxiv\.org\/(?:abs|pdf)\/([0-9]+\.[0-9]+(?:v\d+)?)/);
      if (arxivMatch) {
        const arxivId = arxivMatch[1];
        s2Url = `https://api.semanticscholar.org/graph/v1/paper/ARXIV:${arxivId}?fields=title,abstract,authors,year,venue,externalIds`;
      }
    }
    if (!s2Url) return null;
    try {
      const response = await fetch(s2Url);
      if (!response.ok) return null;
      const data = await response.json();
      return {
        title: data.title,
        abstract: data.abstract ?? void 0,
        authors: data.authors?.map((a) => a.name),
        year: data.year ?? void 0,
        doi: data.externalIds?.DOI ?? void 0,
        arxiv_id: data.externalIds?.ArXiv ?? void 0,
        journal: data.venue ?? void 0,
        url
      };
    } catch {
      return null;
    }
  }
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "save-page-to-incite",
      title: "Save this page to inCite",
      contexts: ["page"]
    });
    chrome.contextMenus.create({
      id: "save-link-to-incite",
      title: "Save link to inCite",
      contexts: ["link"]
    });
  });
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === "save-page-to-incite") {
      const tabId = tab?.id;
      if (!tabId) return;
      const cached = detectedPapers.get(tabId);
      let papers = [];
      if (cached) {
        papers = cached.papers;
      } else {
        const result = await handleGetDetectedPapers();
        papers = result.papers ?? [];
      }
      if (papers.length > 0) {
        await quickSavePapers(papers);
      } else {
        await chrome.action.setBadgeText({ tabId, text: "!" });
        await chrome.action.setBadgeBackgroundColor({ tabId, color: "#E74C3C" });
        setTimeout(() => chrome.action.setBadgeText({ tabId, text: "" }), 2e3);
      }
    }
    if (info.menuItemId === "save-link-to-incite") {
      const linkUrl = info.linkUrl;
      if (!linkUrl) return;
      const paper = await resolveMetadataFromUrl(linkUrl);
      if (paper) {
        await quickSavePapers([paper]);
      } else {
        const tabId = tab?.id;
        if (tabId) {
          await chrome.action.setBadgeText({ tabId, text: "!" });
          await chrome.action.setBadgeBackgroundColor({ tabId, color: "#E74C3C" });
          setTimeout(() => chrome.action.setBadgeText({ tabId, text: "" }), 2e3);
        }
      }
    }
  });
  async function handleMessage(message, _sender) {
    switch (message.type) {
      case "GET_RECOMMENDATIONS":
        return await handleGetRecommendations();
      case "GET_RECOMMENDATIONS_FOR_TEXT":
        return await handleGetRecommendationsForText(message.text);
      case "CHECK_HEALTH":
        return await handleCheckHealth();
      case "GET_SETTINGS":
        return { type: "SETTINGS_RESULT", settings: await loadSettings() };
      case "SAVE_SETTINGS":
        return { type: "SETTINGS_RESULT", settings: await saveSettings(message.settings) };
      case "INSERT_CITATION_REQUEST":
        return await handleInsertCitation(message.recommendation);
      case "INSERT_MULTI_CITATION_REQUEST":
        return await handleInsertMultiCitation(message.recommendations);
      case "GET_DETECTED_PAPERS":
        return await handleGetDetectedPapers();
      case "SAVE_PAPERS":
        return await handleSavePapers(message);
      case "CHECK_LIBRARY":
        return await handleCheckLibrary(message);
      case "GET_COLLECTIONS":
        return await handleGetCollections();
      case "SEARCH_TAGS":
        return await handleSearchTags(message);
      case "UPDATE_LIBRARY_ITEM":
        return await handleUpdateLibraryItem(message);
      default:
        return { error: "Unknown message type" };
    }
  }
  async function handleGetDetectedPapers() {
    const tab = await getActiveTab();
    if (!tab?.id) return { papers: [], type: null };
    const cached = detectedPapers.get(tab.id);
    if (cached) {
      return { papers: cached.papers, type: cached.type };
    }
    try {
      const results = await chrome.tabs.sendMessage(tab.id, { type: "EXTRACT_PAPERS" });
      if (results?.papers?.length > 0) {
        detectedPapers.set(tab.id, {
          type: results.type ?? "single",
          papers: results.papers,
          translatorName: "generic"
        });
        return { papers: results.papers, type: results.type ?? "single" };
      }
    } catch {
    }
    try {
      const injectionResults = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          function getMeta5(names) {
            for (const name of names) {
              const el = document.querySelector(`meta[name="${name}" i], meta[property="${name}" i]`);
              if (el) {
                const content = el.getAttribute("content");
                if (content?.trim()) return content.trim();
              }
            }
            return null;
          }
          function getAllMeta4(name) {
            return Array.from(document.querySelectorAll(`meta[name="${name}" i], meta[property="${name}" i]`)).map((el) => el.getAttribute("content")?.trim()).filter((c) => !!c);
          }
          function inlineExtractFullText() {
            const selectors = [
              ".jig-ncbiinpagenav .tsec",
              "#body .section",
              "article .c-article-body",
              "article .article-body",
              "#article-body",
              ".article-section__content",
              ".article-content",
              '[role="main"] p',
              "article p",
              "main p"
            ];
            for (const selector of selectors) {
              const elements = document.querySelectorAll(selector);
              if (elements.length === 0) continue;
              const paragraphs = [];
              for (const el of elements) {
                if (el.tagName !== "P") {
                  const ps = el.querySelectorAll("p");
                  for (const p of ps) {
                    const text = p.textContent?.trim();
                    if (text && text.length > 30) paragraphs.push(text);
                  }
                } else {
                  const text = el.textContent?.trim();
                  if (text && text.length > 30) paragraphs.push(text);
                }
              }
              const fullText = paragraphs.join("\n\n");
              if (fullText.length >= 200) return fullText;
            }
            return null;
          }
          const title = getMeta5(["citation_title", "DC.Title", "DC.title", "og:title"]);
          if (!title) return { papers: [], type: null };
          const authors = getAllMeta4("citation_author");
          const doi = getMeta5(["citation_doi", "DC.Identifier"]) ?? void 0;
          const abstract = getMeta5(["citation_abstract", "DC.Description", "og:description"]) ?? void 0;
          const journal = getMeta5(["citation_journal_title", "DC.Source"]) ?? void 0;
          const dateStr = getMeta5(["citation_date", "citation_publication_date", "DC.Date"]);
          const year = dateStr ? parseInt(dateStr.match(/(\d{4})/)?.[1] ?? "", 10) || void 0 : void 0;
          const pdf_url = getMeta5(["citation_pdf_url"]) ?? void 0;
          const full_text = inlineExtractFullText() ?? void 0;
          return {
            papers: [{
              title,
              authors: authors.length ? authors : void 0,
              year,
              doi,
              abstract,
              journal,
              url: location.href,
              pdf_url,
              full_text
            }],
            type: "single"
          };
        }
      });
      const result = injectionResults?.[0]?.result;
      if (result && result.papers && result.papers.length > 0) {
        const detectedType = result.type === "multiple" ? "multiple" : "single";
        detectedPapers.set(tab.id, {
          type: detectedType,
          papers: result.papers,
          translatorName: "generic-injected"
        });
        await chrome.action.setPopup({ tabId: tab.id, popup: "popup/popup.html" });
        await updateBadge(tab.id, detectedType, result.papers);
        return { papers: result.papers, type: detectedType };
      }
    } catch {
    }
    return { papers: [], type: null };
  }
  async function handleSavePapers(message) {
    const settings = await loadSettings();
    if (!settings.apiToken) return { error: "Not signed in" };
    const apiClient = await getClient();
    const result = await apiClient.savePapers({
      papers: message.papers,
      collection_id: message.collectionId ?? null,
      tags: message.tags ?? [],
      enrich: message.enrich ?? true
    });
    const tab = await getActiveTab();
    if (tab?.id) {
      await chrome.action.setBadgeText({ tabId: tab.id, text: "\u2713" });
      await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: "#2ECC71" });
    }
    return result;
  }
  async function handleCheckLibrary(message) {
    const settings = await loadSettings();
    if (!settings.apiToken) return { results: [] };
    const apiClient = await getClient();
    const checkPapers = message.papers.map((p) => ({ doi: p.doi ?? null, title: p.title }));
    const results = await apiClient.checkLibrary(checkPapers);
    return { results: results ?? [] };
  }
  async function handleGetCollections() {
    const settings = await loadSettings();
    if (!settings.apiToken) return { collections: [] };
    const apiClient = await getClient();
    const collections = await apiClient.getCollections();
    return { collections };
  }
  async function handleSearchTags(message) {
    const settings = await loadSettings();
    if (!settings.apiToken) return { tags: [] };
    const apiClient = await getClient();
    const tags = await apiClient.searchTags(message.query);
    return { tags };
  }
  async function handleUpdateLibraryItem(message) {
    const settings = await loadSettings();
    if (!settings.apiToken) return { error: "Not signed in" };
    return await apiUpdateLibraryItem(message.canonicalId, message.collectionId, message.tags, settings);
  }
  async function apiUpdateLibraryItem(canonicalId, collectionId, tags, settings) {
    const baseUrl = getActiveUrl(settings);
    const encodedId = encodeURIComponent(canonicalId);
    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json"
    };
    if (settings.apiMode === "cloud" && settings.apiToken) {
      headers["Authorization"] = `Bearer ${settings.apiToken}`;
    }
    const response = await fetch(`${baseUrl}/api/v1/library/papers/${encodedId}/update`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        collection_id: collectionId ?? null,
        tags: tags ?? []
      })
    });
    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(`Update failed (${response.status}): ${text || response.statusText}`);
    }
    return response.json();
  }
  async function getActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ?? null;
  }
  function detectEditorType(url) {
    if (url.includes("docs.google.com/document")) return "googledocs";
    if (url.includes("overleaf.com/project")) return "overleaf";
    return "unknown";
  }
  async function getContextFromTab(tab) {
    const requestId = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("Content script did not respond")), 8e3);
      chrome.tabs.sendMessage(
        tab.id,
        { type: "GET_CONTEXT", requestId },
        (response) => {
          clearTimeout(timeout);
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (response?.error) {
            reject(new Error(response.error));
            return;
          }
          if (response?.text) {
            resolve(response.text);
          } else if (response?.fullText && response.cursorOffset !== void 0) {
            loadSettings().then((settings) => {
              const ctx = extractContext(response.fullText, response.cursorOffset, settings.contextSentences);
              resolve(ctx.text);
            });
          } else {
            reject(new Error("No text selected. Select text and try again."));
          }
        }
      );
    });
  }
  async function handleGetRecommendations() {
    const tab = await getActiveTab();
    if (!tab) return { type: "RECOMMENDATIONS_RESULT", error: "No active tab" };
    const settings = await loadSettings();
    const query = await getContextFromTab(tab);
    const stripped = stripCitations(query);
    if (!stripped || stripped.length < 10) {
      return { type: "RECOMMENDATIONS_RESULT", error: "Selected text is too short for recommendations." };
    }
    const apiClient = await getClient();
    const response = await apiClient.recommend(stripped, settings.k, settings.authorBoost);
    return { type: "RECOMMENDATIONS_RESULT", response };
  }
  async function handleGetRecommendationsForText(text) {
    const settings = await loadSettings();
    const stripped = stripCitations(text);
    if (!stripped || stripped.length < 10) {
      return { type: "RECOMMENDATIONS_RESULT", error: "Text is too short for recommendations." };
    }
    const apiClient = await getClient();
    const response = await apiClient.recommend(stripped, settings.k, settings.authorBoost);
    return { type: "RECOMMENDATIONS_RESULT", response };
  }
  async function handleCheckHealth() {
    try {
      const apiClient = await getClient();
      const response = await apiClient.health();
      return { type: "HEALTH_RESULT", response };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      return { type: "HEALTH_RESULT", error: message };
    }
  }
  async function handleInsertCitation(rec) {
    const tab = await getActiveTab();
    if (!tab?.id) return { type: "INSERT_RESULT", success: false };
    const settings = await loadSettings();
    const editorType = detectEditorType(tab.url ?? "");
    const template = editorType === "overleaf" ? settings.overleafCitationFormat : settings.googleDocsCitationFormat;
    const citation = formatCitation(rec, template);
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(
        tab.id,
        { type: "INSERT_CITATION", citation, editorType },
        (response) => {
          if (chrome.runtime.lastError) {
            resolve({ type: "INSERT_RESULT", success: false });
            return;
          }
          resolve(response ?? { type: "INSERT_RESULT", success: true });
        }
      );
    });
  }
  async function handleInsertMultiCitation(recs) {
    const tab = await getActiveTab();
    if (!tab?.id) return { type: "INSERT_RESULT", success: false };
    const settings = await loadSettings();
    const editorType = detectEditorType(tab.url ?? "");
    const template = editorType === "overleaf" ? settings.overleafCitationFormat : settings.googleDocsCitationFormat;
    const citation = formatMultiCitation(recs, template);
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(
        tab.id,
        { type: "INSERT_CITATION", citation, editorType },
        (response) => {
          if (chrome.runtime.lastError) {
            resolve({ type: "INSERT_RESULT", success: false });
            return;
          }
          resolve(response ?? { type: "INSERT_RESULT", success: true });
        }
      );
    });
  }
})();
//# sourceMappingURL=service-worker.js.map
